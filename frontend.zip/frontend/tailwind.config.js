/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        azure: {
          50: '#f0f7ff',
          100: '#e0effe',
          500: '#0078d4',
          600: '#006cbd',
          700: '#005ba1',
          900: '#003966',
        }
      }
    },
  },
  plugins: [],
}
