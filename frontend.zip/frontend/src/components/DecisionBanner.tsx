import React from 'react';
import { CheckCircle2, XCircle, ArrowUpRight, DollarSign, ShieldAlert, Sparkles } from 'lucide-react';
import { GuardrailAnalysis } from '../types';

interface DecisionBannerProps {
  analysis: GuardrailAnalysis;
}

export const DecisionBanner: React.FC<DecisionBannerProps> = ({ analysis }) => {
  const isApproved = analysis.status === 'APPROVED';

  return (
    <div className={`rounded-2xl border p-6 md:p-8 backdrop-blur shadow-2xl transition-all ${
      isApproved
        ? 'border-emerald-500/40 bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-950 shadow-emerald-950/20'
        : 'border-rose-500/40 bg-gradient-to-br from-rose-950/40 via-slate-900 to-slate-950 shadow-rose-950/20'
    }`}>
      {/* Top Header & Decision Badge */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="flex items-center space-x-4">
          <div className={`p-3 rounded-2xl ${
            isApproved ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
          }`}>
            {isApproved ? <CheckCircle2 className="w-10 h-10" /> : <XCircle className="w-10 h-10" />}
          </div>
          <div>
            <div className="flex items-center space-x-3">
              <span className="text-xs uppercase tracking-wider font-bold text-slate-400">Pre-Deployment Financial Policy</span>
              <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">Live Azure Pricing</span>
            </div>
            <h2 className="text-3xl font-extrabold tracking-tight text-white flex items-center space-x-3 mt-1">
              <span>Status:</span>
              <span className={isApproved ? 'text-emerald-400' : 'text-rose-400'}>
                {isApproved ? 'APPROVED' : 'BLOCKED'}
              </span>
            </h2>
          </div>
        </div>

        {/* Request ID Badge */}
        {analysis.request_id && (
          <div className="text-right">
            <span className="text-xs text-slate-400 block font-mono">Reference ID</span>
            <span className="text-sm font-semibold text-white font-mono bg-slate-800/80 px-3 py-1 rounded-lg border border-slate-700">
              {analysis.request_id}
            </span>
          </div>
        )}
      </div>

      {/* Rationale Callout */}
      <div className="my-6 p-4 rounded-xl bg-slate-800/50 border border-slate-700/60">
        <div className="flex items-start space-x-3">
          <ShieldAlert className={`w-5 h-5 mt-0.5 flex-shrink-0 ${isApproved ? 'text-emerald-400' : 'text-rose-400'}`} />
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Financial Firewall Decision Justification</span>
            <p className="text-sm font-medium text-slate-200 mt-0.5">{analysis.reason}</p>
          </div>
        </div>
      </div>

      {/* Financial Comparison Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2">
        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <span className="text-xs font-medium text-slate-400">Current Monthly Cost</span>
          <div className="text-xl font-bold text-slate-200 mt-1">
            ${analysis.prior_monthly_cost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-xs text-slate-500">Existing footprint</span>
        </div>

        <div className={`p-4 rounded-xl border ${
          isApproved ? 'bg-emerald-950/20 border-emerald-500/20' : 'bg-rose-950/20 border-rose-500/20'
        }`}>
          <span className="text-xs font-medium text-slate-400">Monthly Increase (Delta)</span>
          <div className={`text-xl font-bold mt-1 flex items-center ${
            analysis.monthly_cost_delta >= 0 ? (isApproved ? 'text-emerald-400' : 'text-rose-400') : 'text-blue-400'
          }`}>
            <ArrowUpRight className="w-4 h-4 mr-0.5" />
            ${Math.abs(analysis.monthly_cost_delta).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-xs text-slate-500">Per 730-hour month</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <span className="text-xs font-medium text-slate-400">Projected Monthly Cost</span>
          <div className="text-xl font-bold text-white mt-1">
            ${analysis.proposed_monthly_cost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-xs text-slate-500">Total after deployment</span>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
          <span className="text-xs font-medium text-slate-400">Company Guardrail Limit</span>
          <div className="text-xl font-bold text-amber-400 mt-1">
            ${analysis.max_allowed_increase.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-xs text-slate-500">Max allowed delta</span>
        </div>
      </div>
    </div>
  );
};
