import React from 'react';
import { LucideIcon } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: string;
  subtitle?: string;
  icon: LucideIcon;
  variant?: 'blue' | 'emerald' | 'rose' | 'amber' | 'slate';
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  variant = 'slate'
}) => {
  const variantStyles = {
    blue: 'border-blue-500/20 bg-blue-950/20 text-blue-400',
    emerald: 'border-emerald-500/20 bg-emerald-950/20 text-emerald-400',
    rose: 'border-rose-500/20 bg-rose-950/20 text-rose-400',
    amber: 'border-amber-500/20 bg-amber-950/20 text-amber-400',
    slate: 'border-slate-800 bg-slate-900/60 text-slate-300'
  };

  return (
    <div className={`p-5 rounded-xl border backdrop-blur ${variantStyles[variant]} transition-all hover:border-slate-700`}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">{title}</span>
        <div className="p-2 rounded-lg bg-slate-800/80">
          <Icon className="w-5 h-5" />
        </div>
      </div>
      <div className="mt-2 text-2xl font-bold tracking-tight text-white">{value}</div>
      {subtitle && (
        <div className="mt-1 text-xs text-slate-400 flex items-center space-x-1">
          <span>{subtitle}</span>
        </div>
      )}
    </div>
  );
};
