import React from 'react';
import { ResourceCostItem } from '../types';
import { Server, HardDrive, Network, Database, Check } from 'lucide-react';

interface BreakdownTableProps {
  items: ResourceCostItem[];
}

export const BreakdownTable: React.FC<BreakdownTableProps> = ({ items }) => {
  if (!items || items.length === 0) {
    return (
      <div className="p-8 text-center text-slate-500 border border-slate-800 rounded-xl bg-slate-900/40">
        No billable cloud resource modifications in this plan.
      </div>
    );
  }

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'compute':
        return <Server className="w-4 h-4 text-blue-400" />;
      case 'storage':
        return <HardDrive className="w-4 h-4 text-emerald-400" />;
      case 'networking':
        return <Network className="w-4 h-4 text-purple-400" />;
      default:
        return <Database className="w-4 h-4 text-slate-400" />;
    }
  };

  const getActionBadge = (action: string) => {
    switch (action) {
      case 'CREATE':
        return <span className="px-2 py-0.5 text-xs font-semibold rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">CREATE</span>;
      case 'UPDATE':
        return <span className="px-2 py-0.5 text-xs font-semibold rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">UPDATE</span>;
      case 'DELETE':
        return <span className="px-2 py-0.5 text-xs font-semibold rounded bg-rose-500/10 text-rose-400 border border-rose-500/20">DELETE</span>;
      default:
        return <span className="px-2 py-0.5 text-xs font-semibold rounded bg-slate-500/10 text-slate-400 border border-slate-500/20">NO BILLABLE CHANGE</span>;
    }
  };

  return (
    <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/60 shadow-xl">
      <table className="w-full text-left text-sm text-slate-300">
        <thead className="bg-slate-800/80 text-xs uppercase font-semibold text-slate-400 border-b border-slate-700">
          <tr>
            <th className="py-3 px-4">Resource / Address</th>
            <th className="py-3 px-4">SKU / Sizing</th>
            <th className="py-3 px-4">Region</th>
            <th className="py-3 px-4">Action</th>
            <th className="py-3 px-4 text-center">Qty</th>
            <th className="py-3 px-4">Verified Unit Rate</th>
            <th className="py-3 px-4 text-right">Monthly Cost</th>
            <th className="py-3 px-4 text-right">Delta</th>
            <th className="py-3 px-4 text-center">Source</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800">
          {items.map((item, idx) => (
            <tr key={idx} className="hover:bg-slate-800/40 transition-colors">
              <td className="py-3.5 px-4">
                <div className="flex items-center space-x-2.5">
                  <div className="p-1.5 rounded-lg bg-slate-800 border border-slate-700">
                    {getCategoryIcon(item.category)}
                  </div>
                  <div>
                    <div className="font-semibold text-white">{item.category}</div>
                    <div className="text-xs font-mono text-slate-400 truncate max-w-[200px]" title={item.address}>
                      {item.address.split('.').slice(-1)[0] || item.resource_type}
                    </div>
                  </div>
                </div>
              </td>
              <td className="py-3.5 px-4 font-medium text-slate-200">
                <div>{item.sku}</div>
                <div className="text-xs text-slate-500 font-mono truncate max-w-[150px]">{item.meter_name}</div>
              </td>
              <td className="py-3.5 px-4 text-slate-300">
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs bg-slate-800 border border-slate-700">
                  {item.region}
                </span>
              </td>
              <td className="py-3.5 px-4">
                {getActionBadge(item.action)}
              </td>
              <td className="py-3.5 px-4 text-center font-bold text-white">
                {item.quantity}
              </td>
              <td className="py-3.5 px-4 text-xs font-mono text-slate-300">
                {item.unit_rate_display}
              </td>
              <td className="py-3.5 px-4 text-right font-bold text-white">
                ${item.proposed_monthly_cost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </td>
              <td className="py-3.5 px-4 text-right font-bold">
                <span className={item.monthly_cost_delta > 0 ? 'text-amber-400' : (item.monthly_cost_delta < 0 ? 'text-emerald-400' : 'text-slate-400')}>
                  {item.monthly_cost_delta > 0 ? '+' : ''}${item.monthly_cost_delta.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </td>
              <td className="py-3.5 px-4 text-center">
                {item.pricing_source === 'CACHE' ? (
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-500/10 text-blue-400 border border-blue-500/30" title="Retrieved from embedded SQLite Cache">
                    CACHE
                  </span>
                ) : (
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/30" title="Fetched live from Azure Retail Prices API">
                    AZURE API
                  </span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
