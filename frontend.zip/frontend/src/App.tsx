import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Dashboard } from './pages/Dashboard';
import { NewRequest } from './pages/NewRequest';
import { TerraformAnalyzer } from './pages/TerraformAnalyzer';
import { RequestHistory } from './pages/RequestHistory';
import { Settings } from './pages/Settings';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-100 flex flex-col selection:bg-blue-600 selection:text-white">
      {/* Top Enterprise Navigation */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && <Dashboard onNavigate={setActiveTab} />}
        {activeTab === 'request' && <NewRequest />}
        {activeTab === 'terraform' && <TerraformAnalyzer />}
        {activeTab === 'history' && <RequestHistory />}
        {activeTab === 'settings' && <Settings />}
      </main>

      {/* Enterprise Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-900/50 py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>CostGuard • Financial Firewall for Cloud Infrastructure</span>
          <div className="flex items-center space-x-4">
            <span>Live Azure Retail Prices API</span>
            <span>•</span>
            <span>SQLite Write-Through Cache</span>
            <span>•</span>
            <span>Terraform Compatible</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
