import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { DashboardSummary } from '../types';
import { MetricCard } from '../components/MetricCard';
import { DollarSign, ShieldAlert, TrendingUp, Cloud, PlusCircle, FileCode, CheckCircle2, XCircle, ArrowRight } from 'lucide-react';

interface DashboardProps {
  onNavigate: (tab: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [recentRequests, setRecentRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [sumData, reqData] = await Promise.all([
        api.getDashboardSummary(),
        api.getRequests()
      ]);
      setSummary(sumData);
      setRecentRequests(reqData.slice(0, 5));
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !summary) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center space-y-3">
          <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-sm text-slate-400">Loading CostGuard enterprise metrics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Enterprise Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-gradient-to-r from-slate-900 via-blue-950/30 to-slate-900 p-6 md:p-8">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center space-x-2 text-xs font-semibold uppercase tracking-wider text-blue-400">
              <Cloud className="w-4 h-4" />
              <span>{summary.company_name}</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-extrabold text-white mt-1">
              Cloud Infrastructure Cost Impact & Guardrail
            </h1>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Acting as a pre-deployment financial firewall. Evaluates planned infrastructure changes against live Azure retail rates and enforces company budget policies before resources are provisioned.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('request')}
              className="flex items-center space-x-2 px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm shadow-lg shadow-blue-600/30 transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              <span>New Resource Request</span>
            </button>
            <button
              onClick={() => onNavigate('terraform')}
              className="flex items-center space-x-2 px-4 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-sm transition-all"
            >
              <FileCode className="w-4 h-4" />
              <span>Analyze Terraform Plan</span>
            </button>
          </div>
        </div>
      </div>

      {/* Financial Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Monthly Cloud Budget"
          value={`$${summary.monthly_budget.toLocaleString()}`}
          subtitle="Allocated enterprise ceiling"
          icon={DollarSign}
          variant="blue"
        />
        <MetricCard
          title="Current Cloud Spend"
          value={`$${summary.current_spend.toLocaleString()}`}
          subtitle={`${((summary.current_spend / summary.monthly_budget) * 100).toFixed(1)}% currently committed`}
          icon={Cloud}
          variant="slate"
        />
        <MetricCard
          title="Remaining Budget Headroom"
          value={`$${summary.remaining_budget.toLocaleString()}`}
          subtitle="Available for planned growth"
          icon={TrendingUp}
          variant="emerald"
        />
        <MetricCard
          title="Max Increase Guardrail"
          value={`$${summary.max_allowed_increase.toLocaleString()} / mo`}
          subtitle="Automated firewall threshold"
          icon={ShieldAlert}
          variant="amber"
        />
      </div>

      {/* Budget Utilization Progress Bar */}
      <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 backdrop-blur">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="font-semibold text-slate-300">Projected Budget Utilization</span>
          <span className="font-bold text-white">{summary.budget_utilization_pct}% utilized</span>
        </div>
        <div className="w-full h-3 rounded-full bg-slate-800 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              summary.budget_utilization_pct > 90
                ? 'bg-rose-500'
                : summary.budget_utilization_pct > 70
                ? 'bg-amber-500'
                : 'bg-emerald-500'
            }`}
            style={{ width: `${Math.min(100, summary.budget_utilization_pct)}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-slate-500 mt-2">
          <span>Current: ${summary.current_spend.toLocaleString()}</span>
          <span>Projected: ${summary.projected_spend.toLocaleString()}</span>
          <span>Limit: ${summary.monthly_budget.toLocaleString()}</span>
        </div>
      </div>

      {/* Recent Infrastructure Requests Audit Table */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">Recent Infrastructure Decisions</h2>
            <p className="text-xs text-slate-400">Pre-deployment checks evaluated by CostGuard engine</p>
          </div>
          <button
            onClick={() => onNavigate('history')}
            className="flex items-center space-x-1 text-xs font-semibold text-blue-400 hover:text-blue-300"
          >
            <span>View Complete Audit Trail</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {recentRequests.length === 0 ? (
          <div className="p-8 text-center text-slate-500 border border-slate-800 rounded-xl bg-slate-900/40">
            No infrastructure requests recorded yet. Start by creating a new request or analyzing a Terraform plan.
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/60">
            <table className="w-full text-left text-sm text-slate-300">
              <thead className="bg-slate-800/80 text-xs uppercase font-semibold text-slate-400 border-b border-slate-700">
                <tr>
                  <th className="py-3 px-4">Request ID</th>
                  <th className="py-3 px-4">Submitted By</th>
                  <th className="py-3 px-4">Timestamp</th>
                  <th className="py-3 px-4 text-right">Cost Delta</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4">Policy Reason</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {recentRequests.map((req) => (
                  <tr key={req.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-semibold text-white">
                      {req.id}
                    </td>
                    <td className="py-3.5 px-4 text-slate-300">
                      {req.user_name}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-400">
                      {new Date(req.created_at).toLocaleString()}
                    </td>
                    <td className="py-3.5 px-4 text-right font-bold">
                      <span className={req.monthly_cost_delta > 0 ? 'text-amber-400' : 'text-slate-300'}>
                        ${req.monthly_cost_delta.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} / mo
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      {req.status === 'APPROVED' ? (
                        <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>APPROVED</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/30">
                          <XCircle className="w-3.5 h-3.5" />
                          <span>BLOCKED</span>
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-400 max-w-xs truncate" title={req.decision_reason}>
                      {req.decision_reason}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
