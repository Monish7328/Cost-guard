import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { BudgetSettings } from '../types';
import { Settings as SettingsIcon, Save, Database, Trash2, Check, RefreshCw } from 'lucide-react';

export const Settings: React.FC = () => {
  const [settings, setSettings] = useState<BudgetSettings>({
    company_name: 'Contoso Cloud Enterprise',
    monthly_budget_limit: 10000,
    current_spend: 3200,
    max_allowed_increase: 1000,
    currency: 'USD'
  });
  const [cacheStats, setCacheStats] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [cacheCleared, setCacheCleared] = useState(false);

  useEffect(() => {
    loadSettings();
    loadCacheStats();
  }, []);

  const loadSettings = async () => {
    try {
      const data = await api.getBudgetSettings();
      setSettings(data);
    } catch (err) {
      console.error('Failed to load settings:', err);
    }
  };

  const loadCacheStats = async () => {
    try {
      const stats = await api.getCacheStats();
      setCacheStats(stats);
    } catch (err) {
      console.error('Failed to load cache stats:', err);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      await api.updateBudgetSettings(settings);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to save settings:', err);
    } finally {
      setSaving(false);
    }
  };

  const handleClearCache = async () => {
    try {
      await api.clearCache();
      setCacheCleared(true);
      await loadCacheStats();
      setTimeout(() => setCacheCleared(false), 3000);
    } catch (err) {
      console.error('Failed to clear cache:', err);
    }
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl md:text-3xl font-extrabold text-white flex items-center space-x-2">
          <SettingsIcon className="w-8 h-8 text-blue-500" />
          <span>CostGuard System Settings</span>
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Configure financial guardrail thresholds and inspect embedded SQLite cache performance.
        </p>
      </div>

      {/* Budget Policy Form */}
      <div className="p-6 md:p-8 rounded-2xl border border-slate-800 bg-slate-900/60 backdrop-blur space-y-6">
        <h2 className="text-lg font-bold text-white border-b border-slate-800 pb-3">
          Company Cloud Budget Policy
        </h2>

        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Organization Name</label>
              <input
                type="text"
                value={settings.company_name}
                onChange={(e) => setSettings({ ...settings, company_name: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Billing Currency</label>
              <input
                type="text"
                value={settings.currency}
                disabled
                className="w-full px-3.5 py-2.5 rounded-lg bg-slate-800/50 border border-slate-700/50 text-slate-400 text-sm cursor-not-allowed"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Total Monthly Cloud Budget ($)</label>
              <input
                type="number"
                value={settings.monthly_budget_limit}
                onChange={(e) => setSettings({ ...settings, monthly_budget_limit: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Current Committed Monthly Spend ($)</label>
              <input
                type="number"
                value={settings.current_spend}
                onChange={(e) => setSettings({ ...settings, current_spend: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="md:col-span-2 space-y-1.5">
              <label className="text-xs font-semibold text-amber-400 flex items-center space-x-1">
                <span>Maximum Allowed Increase Threshold ($ / month)</span>
              </label>
              <input
                type="number"
                value={settings.max_allowed_increase}
                onChange={(e) => setSettings({ ...settings, max_allowed_increase: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 rounded-lg bg-slate-800 border border-amber-500/40 text-amber-400 font-bold text-sm focus:outline-none focus:border-amber-400"
              />
              <p className="text-xs text-slate-500">
                Any planned infrastructure change whose monthly cost delta exceeds this threshold is automatically BLOCKED by CostGuard.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3 pt-3">
            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm shadow-lg shadow-blue-600/30 flex items-center space-x-2 transition-all"
            >
              {saving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              <span>Save Budget Guardrail Policy</span>
            </button>
            {savedSuccess && (
              <span className="text-xs text-emerald-400 flex items-center space-x-1">
                <Check className="w-4 h-4" />
                <span>Budget settings updated successfully</span>
              </span>
            )}
          </div>
        </form>
      </div>

      {/* Embedded SQLite Cache Status */}
      <div className="p-6 md:p-8 rounded-2xl border border-slate-800 bg-slate-900/60 backdrop-blur space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center space-x-2">
              <Database className="w-5 h-5 text-indigo-400" />
              <span>Embedded SQLite Write-Through Cache</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              CostGuard caches live Azure Retail Prices locally to accelerate repeated analysis and protect against rate-limiting.
            </p>
          </div>
          <button
            onClick={handleClearCache}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-semibold transition-all"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Price Cache</span>
          </button>
        </div>

        {cacheCleared && (
          <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs">
            SQLite pricing cache has been flushed.
          </div>
        )}

        {cacheStats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800">
              <span className="text-xs text-slate-400">Total Cached SKUs</span>
              <div className="text-xl font-bold text-white mt-0.5">{cacheStats.total_cached_items}</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800">
              <span className="text-xs text-slate-400">Cache Hits</span>
              <div className="text-xl font-bold text-emerald-400 mt-0.5">{cacheStats.hits}</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800">
              <span className="text-xs text-slate-400">Cache Misses</span>
              <div className="text-xl font-bold text-amber-400 mt-0.5">{cacheStats.misses}</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-800/40 border border-slate-800">
              <span className="text-xs text-slate-400">Hit Rate</span>
              <div className="text-xl font-bold text-blue-400 mt-0.5">
                {cacheStats.hits + cacheStats.misses > 0
                  ? `${Math.round((cacheStats.hits / (cacheStats.hits + cacheStats.misses)) * 100)}%`
                  : '100%'}
              </div>
            </div>
          </div>
        )}

        {cacheStats?.by_service && (
          <div className="space-y-2">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Cached Entries by Service</span>
            <div className="flex flex-wrap gap-2">
              {Object.entries(cacheStats.by_service).map(([svc, count]) => (
                <span key={svc} className="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-xs text-slate-300">
                  {svc}: <strong className="text-white">{count as number}</strong>
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
