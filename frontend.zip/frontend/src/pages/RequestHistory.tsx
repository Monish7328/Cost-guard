import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { BreakdownTable } from '../components/BreakdownTable';
import { History, Search, CheckCircle2, XCircle, Eye, Calendar, User, ArrowUpRight, X } from 'lucide-react';

export const RequestHistory: React.FC = () => {
  const [requests, setRequests] = useState<any[]>([]);
  const [filteredRequests, setFilteredRequests] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'APPROVED' | 'BLOCKED'>('ALL');
  const [selectedRequest, setSelectedRequest] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRequests();
  }, []);

  useEffect(() => {
    let result = requests;
    if (statusFilter !== 'ALL') {
      result = result.filter(r => r.status === statusFilter);
    }
    if (searchTerm.trim()) {
      const term = searchTerm.toLowerCase();
      result = result.filter(r =>
        r.id.toLowerCase().includes(term) ||
        r.user_name.toLowerCase().includes(term) ||
        r.decision_reason.toLowerCase().includes(term)
      );
    }
    setFilteredRequests(result);
  }, [searchTerm, statusFilter, requests]);

  const loadRequests = async () => {
    try {
      setLoading(true);
      const data = await api.getRequests();
      setRequests(data);
      setFilteredRequests(data);
    } catch (err) {
      console.error('Failed to load history:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white flex items-center space-x-2">
            <History className="w-8 h-8 text-blue-500" />
            <span>Infrastructure Request Audit Trail</span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Complete financial compliance audit log of all evaluated cloud changes.
          </p>
        </div>

        {/* Filter Bar */}
        <div className="flex items-center space-x-2">
          {(['ALL', 'APPROVED', 'BLOCKED'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                statusFilter === st
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Search Input */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-500" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search by Request ID, user, or reason..."
          className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
        />
      </div>

      {/* Requests Table */}
      {loading ? (
        <div className="py-12 text-center text-slate-400">Loading audit records...</div>
      ) : filteredRequests.length === 0 ? (
        <div className="p-8 text-center text-slate-500 border border-slate-800 rounded-xl bg-slate-900/40">
          No audit records found matching your filters.
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/60 shadow-xl">
          <table className="w-full text-left text-sm text-slate-300">
            <thead className="bg-slate-800/80 text-xs uppercase font-semibold text-slate-400 border-b border-slate-700">
              <tr>
                <th className="py-3 px-4">Request ID</th>
                <th className="py-3 px-4">User</th>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4 text-right">Prior Cost</th>
                <th className="py-3 px-4 text-right">Proposed Cost</th>
                <th className="py-3 px-4 text-right">Monthly Delta</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredRequests.map((req) => (
                <tr key={req.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-white">
                    {req.id}
                  </td>
                  <td className="py-3.5 px-4 text-slate-300 flex items-center space-x-2">
                    <User className="w-3.5 h-3.5 text-slate-500" />
                    <span>{req.user_name}</span>
                  </td>
                  <td className="py-3.5 px-4 text-xs text-slate-400">
                    {new Date(req.created_at).toLocaleString()}
                  </td>
                  <td className="py-3.5 px-4 text-right text-slate-400">
                    ${req.prior_monthly_cost.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-3.5 px-4 text-right font-semibold text-white">
                    ${req.proposed_monthly_cost.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="py-3.5 px-4 text-right font-bold">
                    <span className={req.monthly_cost_delta > 0 ? 'text-amber-400' : 'text-emerald-400'}>
                      ${req.monthly_cost_delta.toLocaleString('en-US', { minimumFractionDigits: 2 })} / mo
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    {req.status === 'APPROVED' ? (
                      <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>APPROVED</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/10 text-rose-400 border border-rose-500/30">
                        <XCircle className="w-3.5 h-3.5" />
                        <span>BLOCKED</span>
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <button
                      onClick={() => setSelectedRequest(req)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-blue-400 transition-colors"
                      title="View details"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Details Drill-Down Modal */}
      {selectedRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6 md:p-8 space-y-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-xl font-bold text-white flex items-center space-x-2">
                  <span>Request Details:</span>
                  <span className="font-mono text-blue-400">{selectedRequest.id}</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Submitted by {selectedRequest.user_name} on {new Date(selectedRequest.created_at).toLocaleString()}
                </p>
              </div>
              <button
                onClick={() => setSelectedRequest(null)}
                className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Decision Callout */}
            <div className={`p-4 rounded-xl border ${
              selectedRequest.status === 'APPROVED' ? 'bg-emerald-950/20 border-emerald-500/30' : 'bg-rose-950/20 border-rose-500/30'
            }`}>
              <div className="flex items-center space-x-2 font-bold">
                {selectedRequest.status === 'APPROVED' ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <XCircle className="w-5 h-5 text-rose-400" />
                )}
                <span className={selectedRequest.status === 'APPROVED' ? 'text-emerald-400' : 'text-rose-400'}>
                  {selectedRequest.status}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1">{selectedRequest.decision_reason}</p>
            </div>

            {/* Financial Summary */}
            <div className="grid grid-cols-3 gap-4">
              <div className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/60">
                <span className="text-xs text-slate-400">Prior Monthly Cost</span>
                <div className="text-base font-bold text-white">${selectedRequest.prior_monthly_cost.toLocaleString()}</div>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/60">
                <span className="text-xs text-slate-400">Monthly Increase</span>
                <div className="text-base font-bold text-amber-400">${selectedRequest.monthly_cost_delta.toLocaleString()}</div>
              </div>
              <div className="p-3.5 rounded-xl bg-slate-800/50 border border-slate-700/60">
                <span className="text-xs text-slate-400">Projected Monthly Total</span>
                <div className="text-base font-bold text-white">${selectedRequest.proposed_monthly_cost.toLocaleString()}</div>
              </div>
            </div>

            {/* Items Breakdown */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-slate-300">Itemized Resource Changes</h4>
              <BreakdownTable items={selectedRequest.items} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
