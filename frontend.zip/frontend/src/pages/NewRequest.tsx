import React, { useState, useEffect } from 'react';
import { api } from '../services/api';
import { ResourceSelectionItem, GuardrailAnalysis, RegionOption } from '../types';
import { DecisionBanner } from '../components/DecisionBanner';
import { BreakdownTable } from '../components/BreakdownTable';
import {
  Server,
  HardDrive,
  Network,
  Plus,
  Trash2,
  Send,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  Layers,
  ShieldCheck
} from 'lucide-react';

export const NewRequest: React.FC = () => {
  const [regions, setRegions] = useState<RegionOption[]>([]);
  const [catalog, setCatalog] = useState<any>(null);

  // Form State
  const [selectedCategory, setSelectedCategory] = useState<'Compute' | 'Storage' | 'Networking'>('Compute');
  const [selectedRegion, setSelectedRegion] = useState('East US');
  const [selectedSku, setSelectedSku] = useState('Standard_D2s_v5');
  const [selectedSizeGb, setSelectedSizeGb] = useState(128);
  const [quantity, setQuantity] = useState(1);

  // Request list (cart-style infrastructure request)
  const [requestedResources, setRequestedResources] = useState<ResourceSelectionItem[]>([]);
  const [analysisResult, setAnalysisResult] = useState<GuardrailAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadMetadata();
  }, []);

  const loadMetadata = async () => {
    try {
      const [regData, catData] = await Promise.all([
        api.getRegions(),
        api.getCatalog()
      ]);
      setRegions(regData);
      setCatalog(catData);
    } catch (err) {
      console.error('Failed to load catalog data:', err);
    }
  };

  // Pre-load Demo Scenario matching Section 29
  const loadDemoScenario = () => {
    setRequestedResources([
      {
        category: 'Compute',
        resource_type: 'Virtual Machine',
        region: 'East US',
        sku: 'Standard_D2s_v5',
        quantity: 2
      },
      {
        category: 'Storage',
        resource_type: 'Managed Disk',
        region: 'East US',
        sku: 'Premium SSD (LRS)',
        size_gb: 128,
        quantity: 2
      },
      {
        category: 'Networking',
        resource_type: 'Gateway',
        region: 'East US',
        sku: 'VpnGw1',
        quantity: 1
      }
    ]);
    setAnalysisResult(null);
  };

  // Pre-load Blocked Scenario
  const loadBlockedScenario = () => {
    setRequestedResources([
      {
        category: 'Compute',
        resource_type: 'Virtual Machine',
        region: 'East US',
        sku: 'Standard_D8s_v5',
        quantity: 5
      },
      {
        category: 'Storage',
        resource_type: 'Managed Disk',
        region: 'East US',
        sku: 'Premium SSD (LRS)',
        size_gb: 1024,
        quantity: 3
      },
      {
        category: 'Networking',
        resource_type: 'Gateway',
        region: 'East US',
        sku: 'VpnGw2',
        quantity: 1
      }
    ]);
    setAnalysisResult(null);
  };

  const handleAddResource = () => {
    let typeName = 'Virtual Machine';
    if (selectedCategory === 'Storage') typeName = 'Managed Disk';
    if (selectedCategory === 'Networking') typeName = 'Gateway';

    const newItem: ResourceSelectionItem = {
      category: selectedCategory,
      resource_type: typeName,
      region: selectedRegion,
      sku: selectedSku,
      size_gb: selectedCategory === 'Storage' ? selectedSizeGb : undefined,
      quantity: Math.max(1, quantity)
    };

    setRequestedResources([...requestedResources, newItem]);
    setAnalysisResult(null); // Clear previous analysis when cart changes
  };

  const handleRemoveResource = (index: number) => {
    const updated = requestedResources.filter((_, idx) => idx !== index);
    setRequestedResources(updated);
    setAnalysisResult(null);
  };

  const handleClearAll = () => {
    setRequestedResources([]);
    setAnalysisResult(null);
  };

  const handleSubmitAnalysis = async () => {
    if (requestedResources.length === 0) return;
    try {
      setLoading(true);
      setError(null);
      const res = await api.analyzeInfrastructureRequest({
        user_name: 'Lead Cloud Architect',
        resources: requestedResources
      });
      setAnalysisResult(res);
    } catch (err: any) {
      setError(err.message || 'An error occurred during analysis');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Page Header with One-Click Demo Loaders */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white">
            New Cloud Infrastructure Request
          </h1>
          <p className="text-sm text-slate-400 mt-0.5">
            Select planned Azure resources to predict live cost impact and evaluate company guardrails.
          </p>
        </div>

        {/* Quick Demo Scenario Loaders */}
        <div className="flex items-center space-x-2">
          <button
            onClick={loadDemoScenario}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-semibold transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Load Demo (Approved Scenario)</span>
          </button>
          <button
            onClick={loadBlockedScenario}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-semibold transition-all"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Load Over-Budget (Blocked)</span>
          </button>
        </div>
      </div>

      {/* Grid: Resource Selector (Left) + Request Queue (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Resource Configuration Form */}
        <div className="lg:col-span-6 space-y-6">
          <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 backdrop-blur space-y-5">
            <h2 className="text-base font-bold text-white flex items-center space-x-2">
              <Layers className="w-4 h-4 text-blue-400" />
              <span>1. Select Resource Category</span>
            </h2>

            {/* Category Tabs */}
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => {
                  setSelectedCategory('Compute');
                  setSelectedSku('Standard_D2s_v5');
                }}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                  selectedCategory === 'Compute'
                    ? 'border-blue-500 bg-blue-500/10 text-white font-semibold'
                    : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:border-slate-700'
                }`}
              >
                <Server className="w-5 h-5 mb-1.5 text-blue-400" />
                <span className="text-xs">Compute (VM)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSelectedCategory('Storage');
                  setSelectedSku('Premium SSD (LRS)');
                  setSelectedSizeGb(128);
                }}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                  selectedCategory === 'Storage'
                    ? 'border-emerald-500 bg-emerald-500/10 text-white font-semibold'
                    : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:border-slate-700'
                }`}
              >
                <HardDrive className="w-5 h-5 mb-1.5 text-emerald-400" />
                <span className="text-xs">Storage (Disk)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSelectedCategory('Networking');
                  setSelectedSku('VpnGw1');
                }}
                className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all ${
                  selectedCategory === 'Networking'
                    ? 'border-purple-500 bg-purple-500/10 text-white font-semibold'
                    : 'border-slate-800 bg-slate-800/40 text-slate-400 hover:border-slate-700'
                }`}
              >
                <Network className="w-5 h-5 mb-1.5 text-purple-400" />
                <span className="text-xs">Gateway</span>
              </button>
            </div>

            {/* Region Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Target Azure Region</label>
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500"
              >
                {regions.map((reg) => (
                  <option key={reg.armRegionName} value={reg.displayName}>
                    {reg.displayName} ({reg.armRegionName})
                  </option>
                ))}
              </select>
            </div>

            {/* SKU and Sizing Configuration */}
            {selectedCategory === 'Compute' && (
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Virtual Machine SKU / Size</label>
                <select
                  value={selectedSku}
                  onChange={(e) => setSelectedSku(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500"
                >
                  <option value="Standard_D2s_v5">Standard_D2s_v5 (2 vCPU, 8 GB RAM) — General Purpose</option>
                  <option value="Standard_D4s_v5">Standard_D4s_v5 (4 vCPU, 16 GB RAM) — General Purpose</option>
                  <option value="Standard_D8s_v5">Standard_D8s_v5 (8 vCPU, 32 GB RAM) — High Compute</option>
                  <option value="Standard_B2s">Standard_B2s (2 vCPU, 4 GB RAM) — Burstable</option>
                  <option value="Standard_B4ms">Standard_B4ms (4 vCPU, 16 GB RAM) — Burstable</option>
                  <option value="Standard_E4s_v5">Standard_E4s_v5 (4 vCPU, 32 GB RAM) — Memory Optimized</option>
                  <option value="Standard_F4s_v2">Standard_F4s_v2 (4 vCPU, 8 GB RAM) — Compute Optimized</option>
                </select>
              </div>
            )}

            {selectedCategory === 'Storage' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Disk Storage Tier</label>
                  <select
                    value={selectedSku}
                    onChange={(e) => setSelectedSku(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500"
                  >
                    <option value="Premium SSD (LRS)">Premium SSD (LRS)</option>
                    <option value="Standard SSD (LRS)">Standard SSD (LRS)</option>
                    <option value="Standard HDD (LRS)">Standard HDD (LRS)</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">Disk Capacity (GB)</label>
                  <select
                    value={selectedSizeGb}
                    onChange={(e) => setSelectedSizeGb(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500"
                  >
                    <option value={32}>32 GB (P4 / E4)</option>
                    <option value={64}>64 GB (P6 / E6)</option>
                    <option value={128}>128 GB (P10 / E10 - Standard)</option>
                    <option value={256}>256 GB (P15 / E15)</option>
                    <option value={512}>512 GB (P20 / E20)</option>
                    <option value={1024}>1024 GB (1 TB - P30 / E30)</option>
                  </select>
                </div>
              </div>
            )}

            {selectedCategory === 'Networking' && (
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">Gateway SKU / Type</label>
                <select
                  value={selectedSku}
                  onChange={(e) => setSelectedSku(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500"
                >
                  <option value="VpnGw1">VPN Gateway (VpnGw1 - 650 Mbps)</option>
                  <option value="VpnGw2">VPN Gateway (VpnGw2 - 1 Gbps)</option>
                  <option value="Standard">Application Gateway (Standard v2)</option>
                  <option value="Standard_NAT">NAT Gateway (Standard)</option>
                </select>
              </div>
            )}

            {/* Quantity Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Instance / Resource Quantity</label>
              <input
                type="number"
                min={1}
                max={50}
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full px-3.5 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Add Button */}
            <button
              type="button"
              onClick={handleAddResource}
              className="w-full flex items-center justify-center space-x-2 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm shadow-lg shadow-blue-600/20 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Add Resource to Request</span>
            </button>
          </div>
        </div>

        {/* Right Column: Infrastructure Request List (Cart) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="p-6 rounded-2xl border border-slate-800 bg-slate-900/60 backdrop-blur space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h2 className="text-base font-bold text-white flex items-center space-x-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>2. Infrastructure Request Queue</span>
                </h2>
                <span className="text-xs text-slate-400">
                  {requestedResources.length} {requestedResources.length === 1 ? 'item' : 'items'} planned
                </span>
              </div>
              {requestedResources.length > 0 && (
                <button
                  onClick={handleClearAll}
                  className="flex items-center space-x-1 text-xs text-slate-400 hover:text-rose-400 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear All</span>
                </button>
              )}
            </div>

            {/* Empty State */}
            {requestedResources.length === 0 ? (
              <div className="py-12 text-center space-y-3">
                <div className="p-3 bg-slate-800/80 rounded-2xl w-fit mx-auto text-slate-500">
                  <Layers className="w-8 h-8" />
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-300">No resources added yet</p>
                  <p className="text-xs text-slate-500 max-w-xs mx-auto mt-1">
                    Select a resource on the left or click 'Load Demo' above to populate realistic Azure infrastructure.
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[360px] overflow-y-auto pr-1">
                {requestedResources.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl border border-slate-800 bg-slate-800/40 hover:bg-slate-800/60 flex items-center justify-between transition-colors"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                          {item.category}
                        </span>
                        <span className="text-sm font-bold text-white">
                          {item.sku} {item.size_gb ? `(${item.size_gb} GB)` : ''}
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 flex items-center space-x-3">
                        <span>Region: {item.region}</span>
                        <span>•</span>
                        <span className="font-semibold text-slate-200">Qty: {item.quantity}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleRemoveResource(idx)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                      title="Remove resource"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Error Message if any */}
            {error && (
              <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center space-x-2">
                <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Submit Guardrail Check CTA */}
            <div className="pt-2">
              <button
                type="button"
                disabled={requestedResources.length === 0 || loading}
                onClick={handleSubmitAnalysis}
                className={`w-full flex items-center justify-center space-x-2 py-3.5 rounded-xl font-bold text-sm shadow-xl transition-all ${
                  requestedResources.length === 0 || loading
                    ? 'bg-slate-800 text-slate-600 cursor-not-allowed border border-slate-700'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                }`}
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Querying Live Azure Prices & Checking Guardrails...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Run CostGuard Analysis & Budget Check</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Analysis Result Section */}
      {analysisResult && (
        <div className="space-y-6 pt-4 border-t border-slate-800">
          <h2 className="text-xl font-bold text-white flex items-center space-x-2">
            <span>CostGuard Financial Analysis</span>
          </h2>
          <DecisionBanner analysis={analysisResult} />
          <div className="space-y-3">
            <h3 className="text-base font-semibold text-slate-300">Line-Item Cost Breakdown</h3>
            <BreakdownTable items={analysisResult.items} />
          </div>
        </div>
      )}
    </div>
  );
};
