import React, { useState } from 'react';
import { api } from '../services/api';
import { GuardrailAnalysis } from '../types';
import { DecisionBanner } from '../components/DecisionBanner';
import { BreakdownTable } from '../components/BreakdownTable';
import { FileCode, Play, Upload, Sparkles, Terminal, Copy, Check } from 'lucide-react';

const SAMPLE_APPROVED_PLAN = {
  format_version: "1.2",
  terraform_version: "1.7.0",
  resource_changes: [
    {
      address: "azurerm_linux_virtual_machine.web_vm_1",
      mode: "managed",
      type: "azurerm_linux_virtual_machine",
      name: "web_vm_1",
      change: {
        actions: ["create"],
        before: null,
        after: {
          location: "eastus",
          size: "Standard_D2s_v5",
          name: "web-vm-prod-1"
        }
      }
    },
    {
      address: "azurerm_linux_virtual_machine.web_vm_2",
      mode: "managed",
      type: "azurerm_linux_virtual_machine",
      name: "web_vm_2",
      change: {
        actions: ["create"],
        before: null,
        after: {
          location: "eastus",
          size: "Standard_D2s_v5",
          name: "web-vm-prod-2"
        }
      }
    },
    {
      address: "azurerm_managed_disk.data_disk_1",
      mode: "managed",
      type: "azurerm_managed_disk",
      name: "data_disk_1",
      change: {
        actions: ["create"],
        before: null,
        after: {
          location: "eastus",
          storage_account_type: "Premium_LRS",
          disk_size_gb: 128
        }
      }
    },
    {
      address: "azurerm_managed_disk.data_disk_2",
      mode: "managed",
      type: "azurerm_managed_disk",
      name: "data_disk_2",
      change: {
        actions: ["create"],
        before: null,
        after: {
          location: "eastus",
          storage_account_type: "Premium_LRS",
          disk_size_gb: 128
        }
      }
    },
    {
      address: "azurerm_virtual_network_gateway.vpn_gw",
      mode: "managed",
      type: "azurerm_virtual_network_gateway",
      name: "vpn_gw",
      change: {
        actions: ["create"],
        before: null,
        after: {
          location: "eastus",
          sku: "VpnGw1",
          type: "Vpn"
        }
      }
    }
  ]
};

const SAMPLE_BLOCKED_PLAN = {
  format_version: "1.2",
  terraform_version: "1.7.0",
  resource_changes: [
    {
      address: "azurerm_linux_virtual_machine.cluster_node_1",
      mode: "managed",
      type: "azurerm_linux_virtual_machine",
      name: "cluster_node_1",
      change: {
        actions: ["create"],
        before: null,
        after: {
          location: "eastus",
          size: "Standard_D8s_v5",
          name: "node-1"
        }
      }
    },
    {
      address: "azurerm_linux_virtual_machine.cluster_node_2",
      mode: "managed",
      type: "azurerm_linux_virtual_machine",
      name: "cluster_node_2",
      change: {
        actions: ["create"],
        before: null,
        after: {
          location: "eastus",
          size: "Standard_D8s_v5",
          name: "node-2"
        }
      }
    },
    {
      address: "azurerm_linux_virtual_machine.cluster_node_3",
      mode: "managed",
      type: "azurerm_linux_virtual_machine",
      name: "cluster_node_3",
      change: {
        actions: ["create"],
        before: null,
        after: {
          location: "eastus",
          size: "Standard_D8s_v5",
          name: "node-3"
        }
      }
    },
    {
      address: "azurerm_linux_virtual_machine.cluster_node_4",
      mode: "managed",
      type: "azurerm_linux_virtual_machine",
      name: "cluster_node_4",
      change: {
        actions: ["create"],
        before: null,
        after: {
          location: "eastus",
          size: "Standard_D8s_v5",
          name: "node-4"
        }
      }
    },
    {
      address: "azurerm_managed_disk.cluster_storage_1",
      mode: "managed",
      type: "azurerm_managed_disk",
      name: "cluster_storage_1",
      change: {
        actions: ["create"],
        before: null,
        after: {
          location: "eastus",
          storage_account_type: "Premium_LRS",
          disk_size_gb: 1024
        }
      }
    },
    {
      address: "azurerm_managed_disk.cluster_storage_2",
      mode: "managed",
      type: "azurerm_managed_disk",
      name: "cluster_storage_2",
      change: {
        actions: ["create"],
        before: null,
        after: {
          location: "eastus",
          storage_account_type: "Premium_LRS",
          disk_size_gb: 1024
        }
      }
    },
    {
      address: "azurerm_virtual_network_gateway.vpn_gw_large",
      mode: "managed",
      type: "azurerm_virtual_network_gateway",
      name: "vpn_gw_large",
      change: {
        actions: ["create"],
        before: null,
        after: {
          location: "eastus",
          sku: "VpnGw2",
          type: "Vpn"
        }
      }
    }
  ]
};

export const TerraformAnalyzer: React.FC = () => {
  const [planText, setPlanText] = useState(JSON.stringify(SAMPLE_APPROVED_PLAN, null, 2));
  const [maxIncrease, setMaxIncrease] = useState<number>(1000);
  const [analysisResult, setAnalysisResult] = useState<GuardrailAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedCli, setCopiedCli] = useState(false);

  const handleAnalyze = async () => {
    try {
      setLoading(true);
      setError(null);
      const parsed = JSON.parse(planText);
      const res = await api.analyzeTerraformPlan(parsed, maxIncrease);
      setAnalysisResult(res);
    } catch (err: any) {
      setError(err.message || 'Failed to parse or analyze Terraform plan');
    } finally {
      setLoading(false);
    }
  };

  const copyCliCommand = () => {
    navigator.clipboard.writeText(`terraform show -json tfplan | costguard --max-increase ${maxIncrease}`);
    setCopiedCli(true);
    setTimeout(() => setCopiedCli(false), 2000);
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white flex items-center space-x-2">
            <FileCode className="w-8 h-8 text-blue-500" />
            <span>Terraform Plan JSON Analyzer</span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Simulate CI/CD pipeline guardrails by inspecting standard <code className="text-blue-400 bg-slate-800 px-1.5 py-0.5 rounded text-xs">terraform show -json</code> plan outputs.
          </p>
        </div>

        {/* CLI Equivalent snippet */}
        <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 p-2.5 rounded-xl">
          <Terminal className="w-4 h-4 text-slate-400" />
          <code className="text-xs text-slate-300 font-mono">
            terraform show -json tfplan | costguard --max-increase {maxIncrease}
          </code>
          <button
            onClick={copyCliCommand}
            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            title="Copy CLI command"
          >
            {copiedCli ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Editor & Controls */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setPlanText(JSON.stringify(SAMPLE_APPROVED_PLAN, null, 2))}
              className="px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-semibold flex items-center space-x-1.5 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Load Approved Sample ($332/mo)</span>
            </button>
            <button
              onClick={() => setPlanText(JSON.stringify(SAMPLE_BLOCKED_PLAN, null, 2))}
              className="px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs font-semibold flex items-center space-x-1.5 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Load Blocked Sample ($1,749/mo)</span>
            </button>
          </div>

          {/* Threshold input */}
          <div className="flex items-center space-x-2 bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded-lg">
            <label className="text-xs font-semibold text-slate-400">Max Allowed Increase:</label>
            <div className="flex items-center text-sm font-bold text-emerald-400">
              <span>$</span>
              <input
                type="number"
                value={maxIncrease}
                onChange={(e) => setMaxIncrease(Number(e.target.value))}
                className="w-20 bg-transparent text-emerald-400 border-none outline-none font-bold text-sm ml-0.5"
              />
            </div>
          </div>
        </div>

        {/* JSON Editor textarea */}
        <div className="relative rounded-2xl border border-slate-800 bg-slate-950 shadow-2xl overflow-hidden">
          <textarea
            rows={14}
            value={planText}
            onChange={(e) => setPlanText(e.target.value)}
            className="w-full bg-slate-950 p-4 font-mono text-xs text-slate-300 border-none outline-none resize-y leading-relaxed"
            placeholder="Paste your Terraform plan JSON output here..."
          />
        </div>

        {error && (
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-sm">
            {error}
          </div>
        )}

        <button
          onClick={handleAnalyze}
          disabled={loading}
          className="w-full py-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-xl shadow-blue-600/30 flex items-center justify-center space-x-2 transition-all"
        >
          {loading ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              <span>Inspecting Resource Changes with CostGuard Engine...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4" />
              <span>Analyze Plan with CostGuard</span>
            </>
          )}
        </button>
      </div>

      {/* Analysis Results */}
      {analysisResult && (
        <div className="space-y-6 pt-6 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white">Engine Guardrail Result</h2>
            <div className="flex items-center space-x-2">
              <span className="text-xs text-slate-400">Simulated Exit Code:</span>
              <span className={`px-2.5 py-0.5 rounded text-xs font-mono font-bold ${
                analysisResult.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
              }`}>
                {analysisResult.status === 'APPROVED' ? '0 (OK)' : '1 (BREACH)'}
              </span>
            </div>
          </div>
          <DecisionBanner analysis={analysisResult} />
          <div className="space-y-3">
            <h3 className="text-base font-semibold text-slate-300">Extracted Resource Changes & Rates</h3>
            <BreakdownTable items={analysisResult.items} />
          </div>
        </div>
      )}
    </div>
  );
};
