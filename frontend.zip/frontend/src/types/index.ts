export type GuardrailStatus = 'APPROVED' | 'BLOCKED';

export interface ResourceCostItem {
  address: string;
  resource_type: string;
  category: string;
  region: string;
  sku: string;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'NO_OP';
  quantity: number;
  unit_rate_display: string;
  unit_of_measure: string;
  prior_monthly_cost: number;
  proposed_monthly_cost: number;
  monthly_cost_delta: number;
  pricing_source: string;
  meter_name: string;
}

export interface GuardrailAnalysis {
  request_id?: string;
  status: GuardrailStatus;
  prior_monthly_cost: number;
  proposed_monthly_cost: number;
  monthly_cost_delta: number;
  budget_limit: number;
  max_allowed_increase: number;
  reason: string;
  items: ResourceCostItem[];
  created_at: string;
  tf_plan_json?: Record<string, any>;
}

export interface ResourceSelectionItem {
  category: 'Compute' | 'Storage' | 'Networking';
  resource_type: string;
  region: string;
  sku: string;
  size_gb?: number;
  quantity: number;
}

export interface InfrastructureRequestPayload {
  user_name: string;
  resources: ResourceSelectionItem[];
  max_allowed_increase?: number;
}

export interface BudgetSettings {
  company_name: string;
  monthly_budget_limit: number;
  current_spend: number;
  max_allowed_increase: number;
  currency: string;
  updated_at?: string;
}

export interface DashboardSummary {
  company_name: string;
  monthly_budget: number;
  current_spend: number;
  projected_spend: number;
  remaining_budget: number;
  budget_utilization_pct: number;
  max_allowed_increase: number;
  total_requests: number;
  approved_requests: number;
  approval_rate: number;
}

export interface RegionOption {
  displayName: string;
  armRegionName: string;
}
