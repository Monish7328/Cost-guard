import {
  GuardrailAnalysis,
  InfrastructureRequestPayload,
  BudgetSettings,
  DashboardSummary,
  RegionOption
} from '../types';

const API_BASE = 'http://localhost:8000/api';

export const api = {
  async getDashboardSummary(): Promise<DashboardSummary> {
    const res = await fetch(`${API_BASE}/dashboard/summary`);
    if (!res.ok) throw new Error('Failed to fetch dashboard summary');
    return res.json();
  },

  async getCatalog(): Promise<any> {
    const res = await fetch(`${API_BASE}/catalog`);
    if (!res.ok) throw new Error('Failed to fetch resource catalog');
    return res.json();
  },

  async getRegions(): Promise<RegionOption[]> {
    const res = await fetch(`${API_BASE}/catalog/regions`);
    if (!res.ok) throw new Error('Failed to fetch Azure regions');
    return res.json();
  },

  async analyzeInfrastructureRequest(payload: InfrastructureRequestPayload): Promise<GuardrailAnalysis> {
    const res = await fetch(`${API_BASE}/costguard/analyze-request`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail || 'Analysis failed');
    }
    return res.json();
  },

  async analyzeTerraformPlan(planJson: Record<string, any>, maxIncrease?: number): Promise<GuardrailAnalysis> {
    const res = await fetch(`${API_BASE}/costguard/analyze-plan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        plan_json: planJson,
        max_allowed_increase: maxIncrease,
        user_name: 'Web DevOps Engineer'
      }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail || 'Terraform plan analysis failed');
    }
    return res.json();
  },

  async getRequests(): Promise<any[]> {
    const res = await fetch(`${API_BASE}/requests`);
    if (!res.ok) throw new Error('Failed to fetch requests history');
    return res.json();
  },

  async getRequestDetails(id: string): Promise<any> {
    const res = await fetch(`${API_BASE}/requests/${id}`);
    if (!res.ok) throw new Error('Failed to fetch request details');
    return res.json();
  },

  async getBudgetSettings(): Promise<BudgetSettings> {
    const res = await fetch(`${API_BASE}/settings/budget`);
    if (!res.ok) throw new Error('Failed to fetch budget settings');
    return res.json();
  },

  async updateBudgetSettings(settings: BudgetSettings): Promise<BudgetSettings> {
    const res = await fetch(`${API_BASE}/settings/budget`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    if (!res.ok) throw new Error('Failed to update budget settings');
    return res.json();
  },

  async getCacheStats(): Promise<any> {
    const res = await fetch(`${API_BASE}/cache/stats`);
    if (!res.ok) throw new Error('Failed to fetch cache statistics');
    return res.json();
  },

  async clearCache(): Promise<any> {
    const res = await fetch(`${API_BASE}/cache/clear`, { method: 'POST' });
    if (!res.ok) throw new Error('Failed to clear cache');
    return res.json();
  }
};
