from costguard.pricing.azure_client import AzureRetailPricesClient

client = AzureRetailPricesClient()
quote = client.get_vm_price("Standard_D16s_v5", "eastus")

print(f"SKU: {quote.arm_sku_name}")
print(f"Meter: {quote.meter_name}")
print(f"Live Price from Azure: ${quote.unit_price} / {quote.unit_of_measure}")
print(f"Monthly Rate (x 730 hrs): ${quote.monthly_unit_rate:.2f} / month")
print(f"Source: {quote.source.value}")
