"""
FastAPI REST API Routes for CostGuard
Connects the Web Dashboard to the underlying CostGuard Core Service.
"""
from fastapi import APIRouter, HTTPException, Query, UploadFile, File
from typing import Dict, Any, List, Optional
from pydantic import BaseModel
import json
from costguard.service import CostGuardService
from costguard.models import (
    GuardrailAnalysis,
    InfrastructureRequestPayload,
    BudgetSettings
)
from costguard.catalog import get_catalog, get_regions_list

router = APIRouter()
service = CostGuardService()


class PlanAnalysisRequest(BaseModel):
    plan_json: Dict[str, Any]
    max_allowed_increase: Optional[float] = None
    user_name: str = "DevOps Engineer"


@router.get("/catalog")
def get_resource_catalog():
    """Retrieve available resource categories, types, SKUs, and sizing options."""
    return get_catalog()


@router.get("/catalog/regions")
def get_supported_regions():
    """Retrieve supported Azure regions with ARM identifiers."""
    return get_regions_list()


@router.post("/costguard/analyze-request", response_model=GuardrailAnalysis)
def analyze_infrastructure_request(payload: InfrastructureRequestPayload):
    """
    Analyze an infrastructure request created via the web portal.
    Converts request to synthetic Terraform plan and runs CostGuard engine.
    """
    try:
        analysis = service.analyze_infrastructure_request(payload)
        return analysis
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/costguard/analyze-plan", response_model=GuardrailAnalysis)
def analyze_terraform_plan(payload: PlanAnalysisRequest):
    """
    Directly analyze an uploaded or pasted Terraform Plan JSON.
    """
    try:
        analysis = service.analyze_terraform_plan(
            plan_input=payload.plan_json,
            max_allowed_increase=payload.max_allowed_increase,
            user_name=payload.user_name
        )
        return analysis
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/costguard/upload-plan", response_model=GuardrailAnalysis)
async def upload_terraform_plan(
    file: UploadFile = File(...),
    max_allowed_increase: Optional[float] = Query(None)
):
    """
    Upload a Terraform Plan JSON file directly.
    """
    try:
        content = await file.read()
        plan_dict = json.loads(content.decode("utf-8"))
        analysis = service.analyze_terraform_plan(
            plan_input=plan_dict,
            max_allowed_increase=max_allowed_increase,
            user_name="DevOps File Upload"
        )
        return analysis
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON file format")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/dashboard/summary")
def get_dashboard_summary():
    """High-level metrics for dashboard cards."""
    try:
        return service.get_dashboard_summary()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/requests")
def list_infrastructure_requests(limit: int = Query(50, ge=1, le=100)):
    """Retrieve historical infrastructure requests and audit trail."""
    try:
        return service.get_requests(limit=limit)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/requests/{request_id}")
def get_request_details(request_id: str):
    """Retrieve full details and breakdown for a specific infrastructure request."""
    req = service.get_request_by_id(request_id)
    if not req:
        raise HTTPException(status_code=404, detail="Request not found")
    return req


@router.get("/settings/budget", response_model=BudgetSettings)
def get_budget_settings():
    """Retrieve current company budget settings and threshold."""
    return service.get_budget_settings()


@router.put("/settings/budget", response_model=BudgetSettings)
def update_budget_settings(settings: BudgetSettings):
    """Update company budget settings and threshold."""
    return service.update_budget_settings(settings)


@router.get("/cache/stats")
def get_cache_statistics():
    """Retrieve SQLite pricing cache hit/miss statistics and entry counts."""
    return service.get_cache_stats()


@router.post("/cache/clear")
def clear_pricing_cache():
    """Clear all cached Azure pricing records from SQLite."""
    service.clear_cache()
    return {"message": "Pricing cache cleared successfully"}
