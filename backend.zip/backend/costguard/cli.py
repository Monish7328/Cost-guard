"""
CostGuard CLI
Command-line interface for analyzing Terraform plans.
Supports piped stdin and file arguments.
Exit codes:
  0 = Approved / within budget
  1 = Blocked / budget breached
  2 = Invalid input / processing error
"""
import sys
import argparse
import json
import logging

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

from costguard.service import CostGuardService
from costguard.guardrail import BudgetGuardrailEngine
from costguard.models import GuardrailStatus

# Configure logging for CLI
logging.basicConfig(level=logging.WARNING, format="%(levelname)s: %(message)s")


def main():
    parser = argparse.ArgumentParser(
        prog="costguard",
        description="CostGuard — Cloud Infrastructure Cost Impact Predictor & Budget Guardrail"
    )
    parser.add_argument(
        "--plan", "-p",
        type=str,
        help="Path to Terraform Plan JSON file (default: read from stdin)"
    )
    parser.add_argument(
        "--max-increase", "-m",
        type=float,
        default=None,
        help="Maximum allowed monthly cost increase threshold (e.g. 500)"
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output results in JSON format instead of ASCII report"
    )
    parser.add_argument(
        "--no-audit",
        action="store_true",
        help="Do not save this analysis to the database audit trail"
    )

    args = parser.parse_args()

    # Read plan input from file or stdin
    plan_content = ""
    if args.plan:
        try:
            with open(args.plan, "r", encoding="utf-8") as f:
                plan_content = f.read()
        except FileNotFoundError:
            sys.stderr.write(f"Error: Plan file '{args.plan}' not found.\n")
            sys.exit(2)
        except Exception as e:
            sys.stderr.write(f"Error reading plan file: {e}\n")
            sys.exit(2)
    else:
        # Check if stdin has data
        if not sys.stdin.isatty():
            plan_content = sys.stdin.read()
        else:
            sys.stderr.write("Error: No Terraform plan provided. Pass --plan <file> or pipe via stdin.\n")
            parser.print_help(sys.stderr)
            sys.exit(2)

    if not plan_content.strip():
        sys.stderr.write("Error: Provided Terraform plan content is empty.\n")
        sys.exit(2)

    try:
        service = CostGuardService()
        analysis = service.analyze_terraform_plan(
            plan_input=plan_content,
            max_allowed_increase=args.max_increase,
            user_name="CLI User",
            save_audit=not args.no_audit
        )

        if args.json:
            print(json.dumps(analysis.dict(), default=str, indent=2))
        else:
            report = BudgetGuardrailEngine.render_ascii_report(analysis)
            print(report)

        # Exit code evaluation
        if analysis.status == GuardrailStatus.APPROVED:
            sys.exit(0)
        else:
            sys.exit(1)

    except Exception as e:
        sys.stderr.write(f"Processing error: {str(e)}\n")
        sys.exit(2)


if __name__ == "__main__":
    main()
