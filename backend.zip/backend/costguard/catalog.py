"""
Azure Resource Catalog & SKU Discovery
Provides curated resource categories, SKUs, and sizing options for the infrastructure request portal.
"""
from typing import Dict, Any, List
from costguard.pricing.region_mapper import get_supported_regions

CATALOG_DATA: Dict[str, Any] = {
    "categories": [
        {
            "id": "compute",
            "name": "Compute",
            "description": "Azure Virtual Machines and scalable compute instances",
            "resourceTypes": [
                {
                    "id": "vm_linux",
                    "name": "Azure Virtual Machine (Linux)",
                    "category": "Compute",
                    "description": "General purpose, burstable, and compute-optimized Linux VMs",
                    "skus": [
                        {
                            "id": "Standard_D2s_v5",
                            "name": "Standard_D2s_v5",
                            "vCpu": 2,
                            "ramGb": 8,
                            "tier": "General Purpose v5",
                            "description": "2 vCPU, 8 GB RAM, Premium Storage supported"
                        },
                        {
                            "id": "Standard_D4s_v5",
                            "name": "Standard_D4s_v5",
                            "vCpu": 4,
                            "ramGb": 16,
                            "tier": "General Purpose v5",
                            "description": "4 vCPU, 16 GB RAM, Premium Storage supported"
                        },
                        {
                            "id": "Standard_D8s_v5",
                            "name": "Standard_D8s_v5",
                            "vCpu": 8,
                            "ramGb": 32,
                            "tier": "General Purpose v5",
                            "description": "8 vCPU, 32 GB RAM, High compute capacity"
                        },
                        {
                            "id": "Standard_B2s",
                            "name": "Standard_B2s",
                            "vCpu": 2,
                            "ramGb": 4,
                            "tier": "Burstable B-series",
                            "description": "2 vCPU, 4 GB RAM, Economical burstable workloads"
                        },
                        {
                            "id": "Standard_B4ms",
                            "name": "Standard_B4ms",
                            "vCpu": 4,
                            "ramGb": 16,
                            "tier": "Burstable B-series",
                            "description": "4 vCPU, 16 GB RAM, Burstable dev/test environments"
                        },
                        {
                            "id": "Standard_E4s_v5",
                            "name": "Standard_E4s_v5",
                            "vCpu": 4,
                            "ramGb": 32,
                            "tier": "Memory Optimized",
                            "description": "4 vCPU, 32 GB RAM, High memory applications"
                        },
                        {
                            "id": "Standard_F4s_v2",
                            "name": "Standard_F4s_v2",
                            "vCpu": 4,
                            "ramGb": 8,
                            "tier": "Compute Optimized",
                            "description": "4 vCPU, 8 GB RAM, High CPU-to-memory ratio"
                        }
                    ]
                }
            ]
        },
        {
            "id": "storage",
            "name": "Storage",
            "description": "Azure Managed Disks and high-performance block storage",
            "resourceTypes": [
                {
                    "id": "managed_disk",
                    "name": "Azure Managed Disk",
                    "category": "Storage",
                    "description": "Persistent block storage attached to Azure VMs",
                    "tiers": [
                        {"id": "Premium_LRS", "name": "Premium SSD (LRS)", "recommended": True},
                        {"id": "StandardSSD_LRS", "name": "Standard SSD (LRS)", "recommended": False},
                        {"id": "Standard_LRS", "name": "Standard HDD (LRS)", "recommended": False}
                    ],
                    "sizes": [
                        {"sizeGb": 32, "diskTier": "P4 / E4", "label": "32 GB"},
                        {"sizeGb": 64, "diskTier": "P6 / E6", "label": "64 GB"},
                        {"sizeGb": 128, "diskTier": "P10 / E10", "label": "128 GB (Standard)", "default": True},
                        {"sizeGb": 256, "diskTier": "P15 / E15", "label": "256 GB"},
                        {"sizeGb": 512, "diskTier": "P20 / E20", "label": "512 GB"},
                        {"sizeGb": 1024, "diskTier": "P30 / E30", "label": "1024 GB (1 TB)"}
                    ]
                }
            ]
        },
        {
            "id": "networking",
            "name": "Networking",
            "description": "Azure Gateways, VPNs, and traffic management",
            "resourceTypes": [
                {
                    "id": "gateway",
                    "name": "Azure Gateway",
                    "category": "Networking",
                    "description": "Secure cross-premises and application gateway routing",
                    "skus": [
                        {
                            "id": "VpnGw1",
                            "name": "VPN Gateway (VpnGw1)",
                            "type": "VPN",
                            "bandwidth": "650 Mbps",
                            "description": "Standard cross-premises VPN gateway (650 Mbps)"
                        },
                        {
                            "id": "VpnGw2",
                            "name": "VPN Gateway (VpnGw2)",
                            "type": "VPN",
                            "bandwidth": "1 Gbps",
                            "description": "High performance site-to-site VPN gateway (1 Gbps)"
                        },
                        {
                            "id": "Standard",
                            "name": "Application Gateway (Standard v2)",
                            "type": "ApplicationGateway",
                            "bandwidth": "Autoscaling",
                            "description": "Layer 7 load balancer with SSL offloading"
                        },
                        {
                            "id": "Standard_NAT",
                            "name": "NAT Gateway",
                            "type": "NATGateway",
                            "bandwidth": "Outbound",
                            "description": "Outbound Internet connectivity for virtual networks"
                        }
                    ]
                }
            ]
        }
    ]
}


def get_catalog() -> Dict[str, Any]:
    return CATALOG_DATA


def get_regions_list() -> List[Dict[str, str]]:
    return get_supported_regions()
