"""
Monthly Cost Calculator
Computes accurate monthly cost projections using the Azure 730 hours/month convention,
handles CREATE, UPDATE, DELETE, and NO_OP actions, and produces an itemized breakdown.
"""
import logging
from typing import List, Tuple
from costguard.models import BillableResource, ActionType, ResourceCostItem, PriceSource
from costguard.extractors.registry import ExtractorRegistry
from costguard.extractors import default_registry
from costguard.pricing.azure_client import AzureRetailPricesClient
from costguard.cache.sqlite_cache import SQLitePriceCache

logger = logging.getLogger("costguard.calculator")


class CostCalculationError(Exception):
    """Raised when cost calculation encounters an unrecoverable pricing failure."""
    pass


class MonthlyCostCalculator:
    """Calculates monthly infrastructure costs and cost deltas."""

    def __init__(
        self,
        pricing_client: AzureRetailPricesClient = None,
        cache: SQLitePriceCache = None,
        registry: ExtractorRegistry = default_registry
    ):
        self.pricing_client = pricing_client or AzureRetailPricesClient()
        self.cache = cache or SQLitePriceCache()
        self.registry = registry

    def calculate_resource_cost(self, resource: BillableResource) -> ResourceCostItem:
        """Calculate prior, proposed, and delta monthly cost for a single resource change."""
        extractor = self.registry.get_extractor(resource.resource_type)
        if not extractor:
            raise CostCalculationError(f"No extractor available for resource type {resource.resource_type}")

        # Fetch current proposed price quote
        quote = extractor.fetch_price(resource, self.pricing_client, self.cache)
        monthly_unit_rate = quote.monthly_unit_rate
        action = resource.action
        qty = max(1, resource.quantity)

        prior_cost = 0.0
        proposed_cost = 0.0

        if action == ActionType.CREATE:
            prior_cost = 0.0
            proposed_cost = monthly_unit_rate * qty
        elif action == ActionType.DELETE:
            prior_cost = monthly_unit_rate * max(1, resource.prior_quantity or qty)
            proposed_cost = 0.0
        elif action == ActionType.NO_OP:
            prior_cost = monthly_unit_rate * qty
            proposed_cost = prior_cost
        elif action == ActionType.UPDATE:
            # Check if prior SKU exists and differs
            if resource.prior_arm_sku_name and resource.prior_arm_sku_name != resource.arm_sku_name:
                prior_resource = resource.copy(update={
                    "arm_sku_name": resource.prior_arm_sku_name,
                    "sku": resource.prior_sku or resource.prior_arm_sku_name
                })
                prior_quote = extractor.fetch_price(prior_resource, self.pricing_client, self.cache)
                prior_cost = prior_quote.monthly_unit_rate * max(1, resource.prior_quantity or qty)
            else:
                prior_cost = monthly_unit_rate * max(1, resource.prior_quantity or qty)
            proposed_cost = monthly_unit_rate * qty

        delta = round(proposed_cost - prior_cost, 2)
        unit_display = f"${quote.unit_price:.4f}/{quote.unit_of_measure} (${monthly_unit_rate:.2f}/mo)"

        return ResourceCostItem(
            address=resource.address,
            resource_type=resource.resource_type,
            category=resource.category.value,
            region=resource.region_display,
            sku=resource.sku,
            action=action,
            quantity=qty,
            unit_rate_display=unit_display,
            unit_of_measure=quote.unit_of_measure,
            prior_monthly_cost=round(prior_cost, 2),
            proposed_monthly_cost=round(proposed_cost, 2),
            monthly_cost_delta=delta,
            pricing_source=quote.source.value,
            meter_name=quote.meter_name
        )

    def calculate_total_costs(
        self,
        resources: List[BillableResource]
    ) -> Tuple[List[ResourceCostItem], float, float, float]:
        """
        Process all billable resources, returning:
        (items, total_prior_monthly_cost, total_proposed_monthly_cost, total_monthly_cost_delta)
        """
        items: List[ResourceCostItem] = []
        total_prior = 0.0
        total_proposed = 0.0

        for res in resources:
            item = self.calculate_resource_cost(res)
            items.append(item)
            total_prior += item.prior_monthly_cost
            total_proposed += item.proposed_monthly_cost

        total_delta = round(total_proposed - total_prior, 2)
        return items, round(total_prior, 2), round(total_proposed, 2), total_delta
