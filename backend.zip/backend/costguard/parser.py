"""
Terraform Plan JSON Parser
Parses standard Terraform 0.12+ / 1.x Plan JSON structures,
identifies resource changes, extracts billable properties,
and synthesizes Terraform plans from UI infrastructure requests.
"""
import json
import logging
from typing import Dict, Any, List, Union
from costguard.models import BillableResource, ResourceSelectionItem, ActionType, ResourceCategory
from costguard.extractors.registry import ExtractorRegistry
from costguard.extractors import default_registry
from costguard.pricing.region_mapper import normalize_region_to_arm

logger = logging.getLogger("costguard.parser")


class TerraformParserError(Exception):
    """Raised when Terraform plan JSON is invalid or cannot be parsed."""
    pass


class TerraformPlanParser:
    """Parses Terraform Plan JSON and generates synthetic plans for UI requests."""

    def __init__(self, registry: ExtractorRegistry = default_registry):
        self.registry = registry

    def parse_plan_data(self, plan_data: Dict[str, Any]) -> List[BillableResource]:
        """Parse dictionary loaded from terraform show -json output."""
        if not isinstance(plan_data, dict):
            raise TerraformParserError("Plan input must be a JSON object")

        resource_changes = plan_data.get("resource_changes")
        if resource_changes is None:
            raise TerraformParserError("Missing 'resource_changes' key in Terraform Plan JSON")

        extracted_resources: List[BillableResource] = []

        for change in resource_changes:
            rtype = change.get("type", "")
            mode = change.get("mode", "managed")
            # Only managed resources cost money (data sources do not incur direct creation costs)
            if mode != "managed":
                continue

            extractor = self.registry.get_extractor(rtype)
            if not extractor:
                logger.debug(f"Skipping unsupported or non-billable resource type: {rtype}")
                continue

            extracted = extractor.extract(change)
            if extracted:
                extracted_resources.append(extracted)

        return extracted_resources

    def parse_plan_string(self, content: str) -> List[BillableResource]:
        """Parse raw JSON string."""
        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            raise TerraformParserError(f"Invalid JSON format: {str(e)}")
        return self.parse_plan_data(data)

    def parse_plan_file(self, file_path: str) -> List[BillableResource]:
        """Read and parse plan JSON from file."""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            return self.parse_plan_string(content)
        except FileNotFoundError:
            raise TerraformParserError(f"Plan file not found: {file_path}")
        except Exception as e:
            raise TerraformParserError(f"Error reading plan file {file_path}: {str(e)}")

    def build_synthetic_plan(self, items: List[ResourceSelectionItem]) -> Dict[str, Any]:
        """
        Convert a list of UI requested items into standard Terraform Plan JSON format.
        This provides 100% architectural parity between CLI and Web Dashboard.
        """
        resource_changes = []
        counter = 1

        for item in items:
            qty = max(1, item.quantity)
            arm_reg = normalize_region_to_arm(item.region)

            for i in range(qty):
                idx_suffix = f"_{counter}" if qty == 1 else f"_{counter}_{i + 1}"

                if item.category == ResourceCategory.COMPUTE:
                    # Virtual Machine
                    rtype = "azurerm_linux_virtual_machine"
                    address = f"azurerm_linux_virtual_machine.vm{idx_suffix}"
                    after_state = {
                        "name": f"costguard-vm{idx_suffix}",
                        "location": arm_reg,
                        "size": item.sku,
                        "os_profile": {"computer_name": f"vm{idx_suffix}"}
                    }
                elif item.category == ResourceCategory.STORAGE:
                    # Managed Disk
                    rtype = "azurerm_managed_disk"
                    address = f"azurerm_managed_disk.disk{idx_suffix}"
                    # Determine tier from SKU string
                    tier = "Premium_LRS"
                    sku_upper = item.sku.upper()
                    if "STANDARD_SSD" in sku_upper or "STANDARD SSD" in sku_upper:
                        tier = "StandardSSD_LRS"
                    elif "STANDARD_LRS" in sku_upper or "STANDARD HDD" in sku_upper:
                        tier = "Standard_LRS"

                    size_gb = item.size_gb or 128
                    after_state = {
                        "name": f"costguard-disk{idx_suffix}",
                        "location": arm_reg,
                        "storage_account_type": tier,
                        "disk_size_gb": size_gb
                    }
                elif item.category == ResourceCategory.NETWORKING:
                    # Gateway
                    sku_lower = item.sku.lower()
                    if "app" in sku_lower:
                        rtype = "azurerm_application_gateway"
                        address = f"azurerm_application_gateway.appgw{idx_suffix}"
                        after_state = {
                            "name": f"costguard-appgw{idx_suffix}",
                            "location": arm_reg,
                            "sku": {"name": item.sku, "tier": "Standard_v2", "capacity": 1}
                        }
                    elif "nat" in sku_lower:
                        rtype = "azurerm_nat_gateway"
                        address = f"azurerm_nat_gateway.natgw{idx_suffix}"
                        after_state = {
                            "name": f"costguard-natgw{idx_suffix}",
                            "location": arm_reg,
                            "sku_name": item.sku
                        }
                    else:
                        rtype = "azurerm_virtual_network_gateway"
                        address = f"azurerm_virtual_network_gateway.vpngw{idx_suffix}"
                        after_state = {
                            "name": f"costguard-vpngw{idx_suffix}",
                            "location": arm_reg,
                            "sku": item.sku,
                            "type": "Vpn"
                        }
                else:
                    counter += 1
                    continue

                resource_changes.append({
                    "address": address,
                    "mode": "managed",
                    "type": rtype,
                    "name": address.split(".")[-1],
                    "provider_name": "registry.terraform.io/hashicorp/azurerm",
                    "change": {
                        "actions": ["create"],
                        "before": None,
                        "after": after_state
                    }
                })
                counter += 1

        return {
            "format_version": "1.2",
            "terraform_version": "1.7.0",
            "resource_changes": resource_changes
        }
