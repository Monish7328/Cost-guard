"""
Azure Region Normalization Layer
Maps between friendly user display names and ARM region identifiers.
"""
from typing import Dict, List, Optional

# Canonical display to ARM region mappings
REGION_MAP: Dict[str, str] = {
    "east us": "eastus",
    "east us 2": "eastus2",
    "west us": "westus",
    "west us 2": "westus2",
    "west us 3": "westus3",
    "central us": "centralus",
    "north central us": "northcentralus",
    "south central us": "southcentralus",
    "west europe": "westeurope",
    "north europe": "northeurope",
    "uk south": "uksouth",
    "uk west": "ukwest",
    "france central": "francecentral",
    "germany west central": "germanywestcentral",
    "central india": "centralindia",
    "south india": "southindia",
    "west india": "westindia",
    "southeast asia": "southeastasia",
    "east asia": "eastasia",
    "australia east": "australiaeast",
    "australia southeast": "australiasoutheast",
    "japan east": "japaneast",
    "japan west": "japanwest",
    "korea central": "koreacentral",
    "brazil south": "brazilsouth",
    "canada central": "canadacentral",
}

# Reverse mapping: ARM region to display name
ARM_TO_DISPLAY: Dict[str, str] = {v: k.title() for k, v in REGION_MAP.items()}


def normalize_region_to_arm(region: str) -> str:
    """
    Convert any region string (display name or raw arm name) to normalized lowercase ARM region name.
    Example: 'East US' -> 'eastus', 'eastus' -> 'eastus', 'Central India' -> 'centralindia'
    """
    if not region:
        return "eastus"
    cleaned = region.strip().lower()
    if cleaned in REGION_MAP:
        return REGION_MAP[cleaned]
    # Check if cleaned is already an ARM name
    for arm_val in REGION_MAP.values():
        if cleaned == arm_val:
            return arm_val
    # Fallback: remove spaces
    return cleaned.replace(" ", "")


def normalize_arm_to_display(arm_region: str) -> str:
    """
    Convert ARM region name to friendly display name.
    Example: 'eastus' -> 'East Us'
    """
    arm = (arm_region or "").strip().lower()
    return ARM_TO_DISPLAY.get(arm, arm.title())


def get_supported_regions() -> List[Dict[str, str]]:
    """Return all standard supported regions for UI selection."""
    return [
        {"displayName": display.title(), "armRegionName": arm}
        for display, arm in sorted(REGION_MAP.items(), key=lambda x: x[0])
    ]
