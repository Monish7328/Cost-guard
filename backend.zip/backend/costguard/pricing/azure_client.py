"""
Live Azure Retail Prices API Client
Queries official public Azure Retail Prices endpoint with strict filtering.
Includes retry logic for network resilience.
Never invents prices. Does not use Spot or Low Priority pricing.
"""
import urllib.request
import urllib.parse
import json
import time
import logging
from typing import Optional, Dict, Any, List
from costguard.models import PriceQuote, PriceSource
from costguard.pricing.region_mapper import normalize_region_to_arm

logger = logging.getLogger("costguard.pricing")
AZURE_PRICES_API_URL = "https://prices.azure.com/api/retail/prices"


class AzurePricingError(Exception):
    """Custom exception raised when Azure pricing lookup fails or resource cannot be priced."""
    pass


class AzureRetailPricesClient:
    """Client for Azure Retail Prices API with retry support."""

    def __init__(self, timeout: int = 15, max_retries: int = 3):
        self.timeout = timeout
        self.max_retries = max_retries

    def _query_api(self, odata_filter: str) -> List[Dict[str, Any]]:
        """Execute query against Azure Retail Prices API with OData filter and retries."""
        encoded_filter = urllib.parse.quote(odata_filter)
        url = f"{AZURE_PRICES_API_URL}?$filter={encoded_filter}"

        last_error = None
        for attempt in range(self.max_retries):
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "CostGuard-PricingEngine/1.0",
                    "Accept": "application/json",
                    "Connection": "close"
                }
            )
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as response:
                    if response.status != 200:
                        raise AzurePricingError(f"Azure Retail Prices API returned HTTP status {response.status}")
                    payload = json.loads(response.read().decode("utf-8"))
                    return payload.get("Items", [])
            except Exception as e:
                last_error = e
                logger.warning(f"Azure API query attempt {attempt + 1} failed: {e}. Retrying...")
                time.sleep(0.5 * (attempt + 1))

        logger.error(f"Network error querying Azure Retail Prices API after {self.max_retries} attempts: {last_error}")
        raise AzurePricingError(f"Failed to connect to Azure Retail Prices API: {str(last_error)}")

    def get_vm_price(self, arm_sku_name: str, region: str, is_windows: bool = False) -> PriceQuote:
        """
        Fetch retail price for an Azure Virtual Machine.
        Filters out Spot and Low Priority instances.
        Calculates monthly rate as hourly_rate * 730.
        """
        arm_region = normalize_region_to_arm(region)
        clean_sku = arm_sku_name.strip()

        odata_filter = (
            f"serviceName eq 'Virtual Machines' and "
            f"armRegionName eq '{arm_region}' and "
            f"priceType eq 'Consumption' and "
            f"armSkuName eq '{clean_sku}'"
        )

        items = self._query_api(odata_filter)

        valid_items = []
        for item in items:
            meter = item.get("meterName", "")
            sku = item.get("skuName", "")
            prod = item.get("productName", "")

            # Exclude Spot and Low Priority
            if "Spot" in meter or "Spot" in sku:
                continue
            if "Low Priority" in meter or "Low Priority" in sku:
                continue

            # Check OS type
            is_win_product = "Windows" in prod
            if is_windows and not is_win_product:
                continue
            if not is_windows and is_win_product:
                continue

            valid_items.append(item)

        if not valid_items:
            # Fallback filter among returned items
            for item in items:
                meter = item.get("meterName", "")
                if "Spot" not in meter and "Low Priority" not in meter:
                    if (is_windows and "Windows" in item.get("productName", "")) or (not is_windows and "Windows" not in item.get("productName", "")):
                        valid_items.append(item)
                        break

        if not valid_items:
            raise AzurePricingError(
                f"No verified consumption retail price found for VM '{clean_sku}' in region '{arm_region}'"
            )

        selected = valid_items[0]
        unit_price = float(selected.get("unitPrice", 0.0))
        unit_of_measure = selected.get("unitOfMeasure", "1 Hour")

        # 730 hours per month convention
        monthly_rate = unit_price * 730.0

        return PriceQuote(
            service_name="Virtual Machines",
            arm_sku_name=clean_sku,
            arm_region_name=arm_region,
            meter_name=selected.get("meterName", clean_sku),
            product_name=selected.get("productName", "Virtual Machine"),
            unit_price=unit_price,
            unit_of_measure=unit_of_measure,
            currency=selected.get("currencyCode", "USD"),
            monthly_unit_rate=monthly_rate,
            source=PriceSource.AZURE_API
        )

    def get_managed_disk_price(self, disk_tier: str, disk_size_gb: int, region: str) -> PriceQuote:
        """
        Fetch retail price for an Azure Managed Disk.
        Disk tiers: Premium_LRS, StandardSSD_LRS, Standard_LRS
        """
        arm_region = normalize_region_to_arm(region)

        size_to_code = {
            32: "4",
            64: "6",
            128: "10",
            256: "15",
            512: "20",
            1024: "30",
            2048: "40",
            4096: "50",
            8192: "60",
            16384: "70",
            32767: "80"
        }

        best_code = "10"
        for sz, code in sorted(size_to_code.items()):
            if disk_size_gb <= sz:
                best_code = code
                break

        tier_upper = disk_tier.upper()
        if "PREMIUM" in tier_upper:
            meter_prefix = f"P{best_code}"
            product_keyword = "Premium SSD Managed Disks"
            redundancy = "ZRS" if "ZRS" in tier_upper else "LRS"
        elif "STANDARDSSD" in tier_upper or "STANDARD_SSD" in tier_upper:
            meter_prefix = f"E{best_code}"
            product_keyword = "Standard SSD Managed Disks"
            redundancy = "ZRS" if "ZRS" in tier_upper else "LRS"
        else:
            meter_prefix = f"S{best_code}"
            product_keyword = "Standard HDD Managed Disks"
            redundancy = "LRS"

        meter_target = f"{meter_prefix} {redundancy} Disk"

        odata_filter = (
            f"serviceName eq 'Storage' and "
            f"armRegionName eq '{arm_region}' and "
            f"priceType eq 'Consumption' and "
            f"contains(productName, '{product_keyword}') and "
            f"contains(meterName, '{meter_prefix} {redundancy}')"
        )

        items = self._query_api(odata_filter)

        selected = None
        for item in items:
            meter = item.get("meterName", "")
            if "Mount" in meter or "Operations" in meter or "Burstable" in meter:
                continue
            if meter_prefix in meter and redundancy in meter:
                selected = item
                break

        if not selected and items:
            for item in items:
                meter = item.get("meterName", "")
                if "Mount" not in meter and "Operations" not in meter:
                    selected = item
                    break

        if not selected:
            raise AzurePricingError(
                f"No verified consumption retail price found for Managed Disk tier '{disk_tier}' ({disk_size_gb}GB) in region '{arm_region}'"
            )

        unit_price = float(selected.get("unitPrice", 0.0))
        unit_of_measure = selected.get("unitOfMeasure", "1/Month")

        if "hour" in unit_of_measure.lower():
            monthly_rate = unit_price * 730.0
        else:
            monthly_rate = unit_price

        return PriceQuote(
            service_name="Storage",
            arm_sku_name=f"{disk_tier}_{disk_size_gb}GB",
            arm_region_name=arm_region,
            meter_name=selected.get("meterName", meter_target),
            product_name=selected.get("productName", "Managed Disk"),
            unit_price=unit_price,
            unit_of_measure=unit_of_measure,
            currency=selected.get("currencyCode", "USD"),
            monthly_unit_rate=monthly_rate,
            source=PriceSource.AZURE_API
        )

    def get_gateway_price(self, gateway_sku: str, gateway_type: str, region: str) -> PriceQuote:
        """
        Fetch retail price for an Azure Gateway.
        """
        arm_region = normalize_region_to_arm(region)
        sku_clean = gateway_sku.strip()
        type_clean = (gateway_type or "").strip().lower()

        if "app" in type_clean or "application" in sku_clean.lower() or "v2" in sku_clean.lower() and "vpn" not in sku_clean.lower():
            odata_filter = (
                f"serviceName eq 'Application Gateway' and "
                f"armRegionName eq '{arm_region}' and "
                f"priceType eq 'Consumption' and "
                f"contains(meterName, 'Fixed')"
            )
            items = self._query_api(odata_filter)
            selected = items[0] if items else None
            service_name = "Application Gateway"
        elif "nat" in type_clean or "nat" in sku_clean.lower():
            odata_filter = (
                f"serviceName eq 'NAT Gateway' and "
                f"armRegionName eq '{arm_region}' and "
                f"priceType eq 'Consumption'"
            )
            items = self._query_api(odata_filter)
            selected = items[0] if items else None
            service_name = "NAT Gateway"
        else:
            odata_filter = (
                f"serviceName eq 'VPN Gateway' and "
                f"armRegionName eq '{arm_region}' and "
                f"priceType eq 'Consumption' and "
                f"contains(meterName, '{sku_clean}')"
            )
            items = self._query_api(odata_filter)
            selected = None
            for item in items:
                meter = item.get("meterName", "")
                if "Connection" in meter or "Add-On" in meter:
                    continue
                selected = item
                break
            if not selected and items:
                selected = items[0]
            service_name = "VPN Gateway"

        if not selected:
            raise AzurePricingError(
                f"No verified consumption retail price found for Gateway SKU '{sku_clean}' ({gateway_type}) in region '{arm_region}'"
            )

        unit_price = float(selected.get("unitPrice", 0.0))
        unit_of_measure = selected.get("unitOfMeasure", "1 Hour")

        if "hour" in unit_of_measure.lower():
            monthly_rate = unit_price * 730.0
        else:
            monthly_rate = unit_price

        return PriceQuote(
            service_name=service_name,
            arm_sku_name=sku_clean,
            arm_region_name=arm_region,
            meter_name=selected.get("meterName", sku_clean),
            product_name=selected.get("productName", service_name),
            unit_price=unit_price,
            unit_of_measure=unit_of_measure,
            currency=selected.get("currencyCode", "USD"),
            monthly_unit_rate=monthly_rate,
            source=PriceSource.AZURE_API
        )
