"""
Pricing package initialization
"""
