"""
Azure Gateway Resource Extractor
Extracts billable attributes from VPN Gateway, Application Gateway, and NAT Gateway blocks.
"""
from typing import Dict, Any, Optional
from costguard.extractors.base import BaseResourceExtractor
from costguard.models import BillableResource, ActionType, ResourceCategory, PriceQuote
from costguard.pricing.azure_client import AzureRetailPricesClient
from costguard.pricing.region_mapper import normalize_region_to_arm, normalize_arm_to_display
from costguard.cache.sqlite_cache import SQLitePriceCache


class GatewayExtractor(BaseResourceExtractor):
    HANDLED_TYPES = [
        "azurerm_virtual_network_gateway",
        "azurerm_application_gateway",
        "azurerm_nat_gateway"
    ]

    def can_handle(self, resource_type: str) -> bool:
        return resource_type in self.HANDLED_TYPES

    def extract(self, resource_change: Dict[str, Any]) -> Optional[BillableResource]:
        address = resource_change.get("address", "azurerm_gateway")
        rtype = resource_change.get("type", "azurerm_virtual_network_gateway")
        change = resource_change.get("change", {})
        actions = change.get("actions", [])
        action = self.determine_action(actions)

        before = change.get("before") or {}
        after = change.get("after") or {}

        # Sku extraction logic across different gateway types
        def _get_gateway_sku(data: dict) -> str:
            if not data:
                return ""
            if "sku" in data:
                sku_val = data["sku"]
                if isinstance(sku_val, dict):
                    return sku_val.get("name") or sku_val.get("tier") or "Standard"
                return str(sku_val)
            if "sku_name" in data:
                return str(data["sku_name"])
            if rtype == "azurerm_nat_gateway":
                return "Standard"
            return "VpnGw1"

        def _get_gateway_type(data: dict) -> str:
            if not data:
                return ""
            if "type" in data:
                return str(data["type"])
            if rtype == "azurerm_application_gateway":
                return "ApplicationGateway"
            if rtype == "azurerm_nat_gateway":
                return "NATGateway"
            return "VPN"

        prior_sku = _get_gateway_sku(before)
        prior_loc = before.get("location")

        sku = _get_gateway_sku(after) or prior_sku or "VpnGw1"
        location = after.get("location") or prior_loc or "eastus"
        gw_type = _get_gateway_type(after) or _get_gateway_type(before)

        if action == ActionType.DELETE:
            sku = prior_sku or sku
            location = prior_loc or location

        if action == ActionType.UPDATE and prior_sku == sku and before.get("location") == after.get("location"):
            action = ActionType.NO_OP

        arm_region = normalize_region_to_arm(location)
        display_region = normalize_arm_to_display(arm_region)

        return BillableResource(
            address=address,
            resource_type=rtype,
            action=action,
            category=ResourceCategory.NETWORKING,
            region_display=display_region,
            arm_region_name=arm_region,
            sku=sku,
            arm_sku_name=sku,
            quantity=1,
            size_spec=gw_type,
            prior_sku=prior_sku if prior_sku else None,
            prior_arm_sku_name=prior_sku if prior_sku else None,
            prior_quantity=1 if prior_sku else 0,
            raw_attributes={
                "gateway_type": gw_type,
                "sku": sku
            }
        )

    def fetch_price(
        self,
        resource: BillableResource,
        pricing_client: AzureRetailPricesClient,
        cache: SQLitePriceCache
    ) -> PriceQuote:
        gw_type = resource.raw_attributes.get("gateway_type", "VPN")
        sku = resource.arm_sku_name

        def _fetch():
            return pricing_client.get_gateway_price(
                gateway_sku=sku,
                gateway_type=gw_type,
                region=resource.arm_region_name
            )

        if "app" in gw_type.lower():
            cache_service = "Application Gateway"
        elif "nat" in gw_type.lower():
            cache_service = "NAT Gateway"
        else:
            cache_service = "VPN Gateway"

        return cache.get_or_fetch(
            service_name=cache_service,
            arm_sku_name=sku,
            arm_region_name=resource.arm_region_name,
            fetch_fn=_fetch
        )
