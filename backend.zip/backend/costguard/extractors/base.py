"""
Base Resource Extractor Interface
Extensible foundation for extracting billable metadata from Terraform resource changes.
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from costguard.models import BillableResource, ActionType, PriceQuote
from costguard.pricing.azure_client import AzureRetailPricesClient
from costguard.cache.sqlite_cache import SQLitePriceCache


class BaseResourceExtractor(ABC):
    """Abstract base extractor for Azure cloud resources."""

    @abstractmethod
    def can_handle(self, resource_type: str) -> bool:
        """Return True if this extractor can handle the specified Terraform resource type."""
        pass

    @abstractmethod
    def extract(self, resource_change: Dict[str, Any]) -> Optional[BillableResource]:
        """
        Parse Terraform resource_change block and return a normalized BillableResource.
        Returns None if the change represents a no-op or non-billable modification.
        """
        pass

    @abstractmethod
    def fetch_price(
        self,
        resource: BillableResource,
        pricing_client: AzureRetailPricesClient,
        cache: SQLitePriceCache
    ) -> PriceQuote:
        """Fetch the monthly price quote using cache and pricing client."""
        pass

    @staticmethod
    def determine_action(actions: list) -> ActionType:
        """Map Terraform change actions list to ActionType."""
        if not actions or actions == ["no-op"]:
            return ActionType.NO_OP
        if "delete" in actions and "create" in actions:
            return ActionType.UPDATE
        if "create" in actions:
            return ActionType.CREATE
        if "delete" in actions:
            return ActionType.DELETE
        if "update" in actions:
            return ActionType.UPDATE
        return ActionType.NO_OP
