"""
Extractors package initialization
"""
from costguard.extractors.registry import ExtractorRegistry
from costguard.extractors.vm import VirtualMachineExtractor
from costguard.extractors.disk import ManagedDiskExtractor
from costguard.extractors.gateway import GatewayExtractor

# Initialize standard extractors into default registry
default_registry = ExtractorRegistry()
default_registry.register(VirtualMachineExtractor())
default_registry.register(ManagedDiskExtractor())
default_registry.register(GatewayExtractor())
