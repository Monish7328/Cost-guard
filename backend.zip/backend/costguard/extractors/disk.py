"""
Azure Managed Disk Resource Extractor
Extracts billable attributes from Terraform Managed Disk resource blocks.
"""
from typing import Dict, Any, Optional
from costguard.extractors.base import BaseResourceExtractor
from costguard.models import BillableResource, ActionType, ResourceCategory, PriceQuote
from costguard.pricing.azure_client import AzureRetailPricesClient
from costguard.pricing.region_mapper import normalize_region_to_arm, normalize_arm_to_display
from costguard.cache.sqlite_cache import SQLitePriceCache


class ManagedDiskExtractor(BaseResourceExtractor):
    HANDLED_TYPES = [
        "azurerm_managed_disk"
    ]

    def can_handle(self, resource_type: str) -> bool:
        return resource_type in self.HANDLED_TYPES

    def extract(self, resource_change: Dict[str, Any]) -> Optional[BillableResource]:
        address = resource_change.get("address", "azurerm_managed_disk")
        rtype = resource_change.get("type", "azurerm_managed_disk")
        change = resource_change.get("change", {})
        actions = change.get("actions", [])
        action = self.determine_action(actions)

        before = change.get("before") or {}
        after = change.get("after") or {}

        # Attributes
        prior_tier = before.get("storage_account_type")
        prior_size = before.get("disk_size_gb")
        prior_loc = before.get("location")

        tier = after.get("storage_account_type") or prior_tier or "Premium_LRS"
        size_gb = after.get("disk_size_gb") or prior_size or 128
        location = after.get("location") or prior_loc or "eastus"

        if action == ActionType.DELETE:
            tier = prior_tier or tier
            size_gb = prior_size or size_gb
            location = prior_loc or location

        if action == ActionType.UPDATE and prior_tier == tier and prior_size == size_gb and before.get("location") == after.get("location"):
            action = ActionType.NO_OP

        arm_region = normalize_region_to_arm(location)
        display_region = normalize_arm_to_display(arm_region)

        sku_display = f"{tier.replace('_', ' ')} ({size_gb} GB)"
        canonical_sku = f"{tier}_{size_gb}GB"

        prior_sku_display = f"{prior_tier.replace('_', ' ')} ({prior_size} GB)" if prior_tier else None
        prior_canonical_sku = f"{prior_tier}_{prior_size}GB" if prior_tier else None

        return BillableResource(
            address=address,
            resource_type=rtype,
            action=action,
            category=ResourceCategory.STORAGE,
            region_display=display_region,
            arm_region_name=arm_region,
            sku=sku_display,
            arm_sku_name=canonical_sku,
            quantity=1,
            size_spec=f"{size_gb} GB",
            prior_sku=prior_sku_display,
            prior_arm_sku_name=prior_canonical_sku,
            prior_quantity=1 if prior_tier else 0,
            raw_attributes={
                "storage_account_type": tier,
                "disk_size_gb": int(size_gb)
            }
        )

    def fetch_price(
        self,
        resource: BillableResource,
        pricing_client: AzureRetailPricesClient,
        cache: SQLitePriceCache
    ) -> PriceQuote:
        tier = resource.raw_attributes.get("storage_account_type", "Premium_LRS")
        size_gb = resource.raw_attributes.get("disk_size_gb", 128)

        def _fetch():
            return pricing_client.get_managed_disk_price(
                disk_tier=tier,
                disk_size_gb=size_gb,
                region=resource.arm_region_name
            )

        return cache.get_or_fetch(
            service_name="Storage",
            arm_sku_name=resource.arm_sku_name,
            arm_region_name=resource.arm_region_name,
            fetch_fn=_fetch
        )
