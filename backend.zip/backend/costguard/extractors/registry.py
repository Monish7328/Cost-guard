"""
Extractor Registry
Allows dynamic registration and lookup of resource extractors.
Enables CostGuard to support new Azure resources without modifying existing code.
"""
from typing import List, Optional
from costguard.extractors.base import BaseResourceExtractor


class ExtractorRegistry:
    """Registry managing resource extractors."""

    def __init__(self):
        self._extractors: List[BaseResourceExtractor] = []

    def register(self, extractor: BaseResourceExtractor):
        """Register a new resource extractor."""
        if extractor not in self._extractors:
            self._extractors.append(extractor)

    def get_extractor(self, resource_type: str) -> Optional[BaseResourceExtractor]:
        """Find an extractor capable of handling resource_type."""
        for extractor in self._extractors:
            if extractor.can_handle(resource_type):
                return extractor
        return None

    def list_supported_types(self) -> List[str]:
        """List of supported Terraform types."""
        # Query extractors
        types = []
        for ext in self._extractors:
            if hasattr(ext, "HANDLED_TYPES"):
                types.extend(ext.HANDLED_TYPES)
        return types
