"""
Azure Virtual Machine Resource Extractor
Extracts billable attributes from Terraform VM resource blocks.
"""
from typing import Dict, Any, Optional
from costguard.extractors.base import BaseResourceExtractor
from costguard.models import BillableResource, ActionType, ResourceCategory, PriceQuote
from costguard.pricing.azure_client import AzureRetailPricesClient
from costguard.pricing.region_mapper import normalize_region_to_arm, normalize_arm_to_display
from costguard.cache.sqlite_cache import SQLitePriceCache


class VirtualMachineExtractor(BaseResourceExtractor):
    HANDLED_TYPES = [
        "azurerm_linux_virtual_machine",
        "azurerm_windows_virtual_machine",
        "azurerm_virtual_machine"
    ]

    def can_handle(self, resource_type: str) -> bool:
        return resource_type in self.HANDLED_TYPES

    def extract(self, resource_change: Dict[str, Any]) -> Optional[BillableResource]:
        address = resource_change.get("address", "azurerm_virtual_machine")
        rtype = resource_change.get("type", "azurerm_linux_virtual_machine")
        change = resource_change.get("change", {})
        actions = change.get("actions", [])
        action = self.determine_action(actions)

        before = change.get("before") or {}
        after = change.get("after") or {}

        # Prior attributes
        prior_sku = before.get("size") or before.get("vm_size")
        prior_loc = before.get("location")

        # Proposed attributes
        sku = after.get("size") or after.get("vm_size") or prior_sku
        location = after.get("location") or prior_loc or "eastus"

        if action == ActionType.DELETE:
            sku = prior_sku
            location = prior_loc or "eastus"

        if not sku:
            return None

        # Check if update is non-billable (e.g., tags change only)
        if action == ActionType.UPDATE and prior_sku == sku and before.get("location") == after.get("location"):
            action = ActionType.NO_OP

        arm_region = normalize_region_to_arm(location)
        display_region = normalize_arm_to_display(arm_region)

        # Detect Windows vs Linux
        is_windows = (
            "windows" in rtype.lower() or
            bool(after.get("os_profile_windows_config")) or
            bool(before.get("os_profile_windows_config"))
        )

        return BillableResource(
            address=address,
            resource_type=rtype,
            action=action,
            category=ResourceCategory.COMPUTE,
            region_display=display_region,
            arm_region_name=arm_region,
            sku=sku,
            arm_sku_name=sku,
            quantity=1,
            size_spec=sku,
            prior_sku=prior_sku,
            prior_arm_sku_name=prior_sku,
            prior_quantity=1 if prior_sku else 0,
            raw_attributes={"is_windows": is_windows}
        )

    def fetch_price(
        self,
        resource: BillableResource,
        pricing_client: AzureRetailPricesClient,
        cache: SQLitePriceCache
    ) -> PriceQuote:
        is_windows = resource.raw_attributes.get("is_windows", False)
        target_sku = resource.arm_sku_name

        def _fetch():
            return pricing_client.get_vm_price(
                arm_sku_name=target_sku,
                region=resource.arm_region_name,
                is_windows=is_windows
            )

        cache_service = "Virtual Machines Windows" if is_windows else "Virtual Machines"
        return cache.get_or_fetch(
            service_name=cache_service,
            arm_sku_name=target_sku,
            arm_region_name=resource.arm_region_name,
            fetch_fn=_fetch
        )
