"""
CostGuard Domain Models and Schemas
"""
from enum import Enum
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime


class ActionType(str, Enum):
    CREATE = "CREATE"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    NO_OP = "NO_OP"


class GuardrailStatus(str, Enum):
    APPROVED = "APPROVED"
    BLOCKED = "BLOCKED"


class ResourceCategory(str, Enum):
    COMPUTE = "Compute"
    STORAGE = "Storage"
    NETWORKING = "Networking"


class PriceSource(str, Enum):
    CACHE = "CACHE"
    AZURE_API = "AZURE_API"


class PriceQuote(BaseModel):
    service_name: str
    arm_sku_name: str
    arm_region_name: str
    meter_name: str
    product_name: str
    unit_price: float
    unit_of_measure: str
    currency: str = "USD"
    monthly_unit_rate: float
    source: PriceSource = PriceSource.AZURE_API


class BillableResource(BaseModel):
    address: str
    resource_type: str
    action: ActionType
    category: ResourceCategory
    region_display: str
    arm_region_name: str
    sku: str
    arm_sku_name: str
    quantity: int = 1
    size_spec: Optional[str] = None
    prior_sku: Optional[str] = None
    prior_arm_sku_name: Optional[str] = None
    prior_quantity: int = 0
    raw_attributes: Dict[str, Any] = Field(default_factory=dict)


class ResourceCostItem(BaseModel):
    address: str
    resource_type: str
    category: str
    region: str
    sku: str
    action: ActionType
    quantity: int
    unit_rate_display: str
    unit_of_measure: str
    prior_monthly_cost: float
    proposed_monthly_cost: float
    monthly_cost_delta: float
    pricing_source: str
    meter_name: str


class GuardrailAnalysis(BaseModel):
    request_id: Optional[str] = None
    status: GuardrailStatus
    prior_monthly_cost: float
    proposed_monthly_cost: float
    monthly_cost_delta: float
    budget_limit: float
    max_allowed_increase: float
    reason: str
    items: List[ResourceCostItem] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    tf_plan_json: Optional[Dict[str, Any]] = None


class ResourceSelectionItem(BaseModel):
    category: ResourceCategory
    resource_type: str  # e.g., "Virtual Machine", "Managed Disk", "Gateway"
    region: str         # e.g., "East US"
    sku: str            # e.g., "Standard_D2s_v5", "Premium SSD P10", "VpnGw1"
    size_gb: Optional[int] = None
    quantity: int = 1


class InfrastructureRequestPayload(BaseModel):
    user_name: str = "Developer"
    resources: List[ResourceSelectionItem]
    max_allowed_increase: Optional[float] = None


class BudgetSettings(BaseModel):
    company_name: str = "Contoso Cloud Enterprise"
    monthly_budget_limit: float = 10000.0
    current_spend: float = 3200.0
    max_allowed_increase: float = 1000.0
    currency: str = "USD"
    updated_at: Optional[datetime] = None
