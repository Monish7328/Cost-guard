"""
CostGuard module entrypoint for python -m costguard
"""
from costguard.cli import main

if __name__ == "__main__":
    main()
