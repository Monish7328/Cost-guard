"""
Budget Guardrail & Financial Firewall Engine
Applies company cost policies to infrastructure plans.
Determines whether changes are APPROVED or BLOCKED.
Generates enterprise ASCII reports for terminal display.
"""
from typing import List, Dict, Any, Optional
from costguard.models import (
    GuardrailStatus,
    GuardrailAnalysis,
    ResourceCostItem
)


class BudgetGuardrailEngine:
    """Enforces company budget limits on infrastructure cost deltas."""

    def __init__(self, default_max_increase: float = 1000.0):
        self.default_max_increase = default_max_increase

    def evaluate(
        self,
        items: List[ResourceCostItem],
        prior_monthly_cost: float,
        proposed_monthly_cost: float,
        cost_delta: float,
        max_allowed_increase: Optional[float] = None,
        request_id: Optional[str] = None,
        tf_plan_json: Optional[Dict[str, Any]] = None
    ) -> GuardrailAnalysis:
        """
        Evaluate cost delta against allowed increase threshold.
        """
        threshold = max_allowed_increase if max_allowed_increase is not None else self.default_max_increase

        if cost_delta <= threshold:
            status = GuardrailStatus.APPROVED
            reason = (
                f"Projected monthly increase of ${cost_delta:,.2f} is within "
                f"the company's allowed budget limit of ${threshold:,.2f}."
            )
        else:
            status = GuardrailStatus.BLOCKED
            overrun = cost_delta - threshold
            reason = (
                f"Projected monthly increase of ${cost_delta:,.2f} exceeds "
                f"the company budget limit of ${threshold:,.2f} by ${overrun:,.2f}."
            )

        return GuardrailAnalysis(
            request_id=request_id,
            status=status,
            prior_monthly_cost=prior_monthly_cost,
            proposed_monthly_cost=proposed_monthly_cost,
            monthly_cost_delta=cost_delta,
            budget_limit=threshold,
            max_allowed_increase=threshold,
            reason=reason,
            items=items,
            tf_plan_json=tf_plan_json
        )

    @staticmethod
    def render_ascii_report(analysis: GuardrailAnalysis) -> str:
        """
        Render enterprise terminal report matching Section 14 of specification.
        Uses clean terminal-safe markers.
        """
        sep = "=" * 60
        sub_sep = "-" * 60

        status_symbol = "[APPROVED]" if analysis.status == GuardrailStatus.APPROVED else "[BLOCKED]"

        lines = [
            sep,
            "                   COSTGUARD ANALYSIS",
            sep,
            f"Current Monthly Cost       ${analysis.prior_monthly_cost:>12,.2f}",
            f"Projected Monthly Cost     ${analysis.proposed_monthly_cost:>12,.2f}",
            f"Monthly Increase           ${analysis.monthly_cost_delta:>12,.2f}",
            f"Company Limit              ${analysis.max_allowed_increase:>12,.2f}",
            sub_sep,
            "",
            "STATUS:",
            f"             {status_symbol}",
            "",
            "Reason:",
            f"{analysis.reason}",
            "",
            sub_sep,
            "RESOURCE BREAKDOWN",
            ""
        ]

        if not analysis.items:
            lines.append("  (No billable resource changes found)")
        else:
            for item in analysis.items:
                lines.append(f"* {item.category}: {item.resource_type}")
                lines.append(f"  SKU: {item.sku}")
                lines.append(f"  Region: {item.region}")
                lines.append(f"  Action: {item.action.value} | Quantity: {item.quantity}")
                lines.append(f"  Unit Rate: {item.unit_rate_display} [{item.pricing_source}]")
                lines.append(f"  Monthly Cost: ${item.proposed_monthly_cost:,.2f} (Delta: ${item.monthly_cost_delta:+,.2f})")
                lines.append("")

        lines.append(sep)
        return "\n".join(lines)
