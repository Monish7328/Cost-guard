"""
CostGuard Unified Core Service
Central orchestrator combining parser, extractors, live pricing, write-through cache,
cost calculator, guardrail policy, and database audit persistence.
Used identically by both the CLI and Web Dashboard.
"""
import logging
from typing import Dict, Any, Union, Optional
from costguard.parser import TerraformPlanParser
from costguard.extractors import default_registry
from costguard.pricing.azure_client import AzureRetailPricesClient
from costguard.cache.sqlite_cache import SQLitePriceCache
from costguard.calculator import MonthlyCostCalculator
from costguard.guardrail import BudgetGuardrailEngine
from costguard.db import CostGuardDatabase
from costguard.models import (
    GuardrailAnalysis,
    InfrastructureRequestPayload,
    GuardrailStatus,
    BudgetSettings
)

logger = logging.getLogger("costguard.service")


class CostGuardService:
    """Unified service coordinating all CostGuard functionality."""

    def __init__(
        self,
        db: Optional[CostGuardDatabase] = None,
        cache: Optional[SQLitePriceCache] = None,
        pricing_client: Optional[AzureRetailPricesClient] = None
    ):
        self.db = db or CostGuardDatabase()
        self.cache = cache or SQLitePriceCache(db_path=self.db.db_path)
        self.pricing_client = pricing_client or AzureRetailPricesClient()
        self.parser = TerraformPlanParser(registry=default_registry)
        self.calculator = MonthlyCostCalculator(
            pricing_client=self.pricing_client,
            cache=self.cache,
            registry=default_registry
        )
        self.guardrail = BudgetGuardrailEngine()

    def analyze_terraform_plan(
        self,
        plan_input: Union[str, Dict[str, Any]],
        max_allowed_increase: Optional[float] = None,
        user_name: str = "DevOps Engineer",
        save_audit: bool = True
    ) -> GuardrailAnalysis:
        """Analyze a Terraform Plan JSON string, file path, or dictionary."""
        # 1. Parse plan into BillableResources
        if isinstance(plan_input, dict):
            resources = self.parser.parse_plan_data(plan_input)
            raw_plan_dict = plan_input
        elif isinstance(plan_input, str):
            try:
                # Try parsing as JSON string directly
                resources = self.parser.parse_plan_string(plan_input)
                import json
                raw_plan_dict = json.loads(plan_input)
            except Exception:
                # If not raw JSON, try file path
                resources = self.parser.parse_plan_file(plan_input)
                import json
                with open(plan_input, "r", encoding="utf-8") as f:
                    raw_plan_dict = json.load(f)
        else:
            raise ValueError("Unsupported plan_input format")

        # 2. Get active budget limit
        settings = self.db.get_budget_settings()
        effective_limit = max_allowed_increase if max_allowed_increase is not None else settings.max_allowed_increase

        # 3. Calculate costs
        items, prior_cost, proposed_cost, delta = self.calculator.calculate_total_costs(resources)

        # 4. Evaluate budget guardrail
        analysis = self.guardrail.evaluate(
            items=items,
            prior_monthly_cost=prior_cost,
            proposed_monthly_cost=proposed_cost,
            cost_delta=delta,
            max_allowed_increase=effective_limit,
            tf_plan_json=raw_plan_dict
        )

        # 5. Persist audit trail if requested
        if save_audit:
            req_id = self.db.save_request(
                analysis=analysis,
                user_name=user_name,
                raw_resources=[r.dict() for r in resources],
                tf_plan=raw_plan_dict
            )
            analysis.request_id = req_id

        return analysis

    def analyze_infrastructure_request(
        self,
        payload: InfrastructureRequestPayload,
        save_audit: bool = True
    ) -> GuardrailAnalysis:
        """
        Analyze a high-level UI infrastructure request.
        Converts the request into synthetic Terraform plan JSON, ensuring
        identical core pipeline execution.
        """
        # 1. Synthesize standard Terraform Plan JSON
        synthetic_plan = self.parser.build_synthetic_plan(payload.resources)

        # 2. Execute standard analysis pipeline
        analysis = self.analyze_terraform_plan(
            plan_input=synthetic_plan,
            max_allowed_increase=payload.max_allowed_increase,
            user_name=payload.user_name,
            save_audit=save_audit
        )
        return analysis

    def get_dashboard_summary(self) -> Dict[str, Any]:
        return self.db.get_dashboard_summary()

    def get_requests(self, limit: int = 50) -> list:
        return self.db.list_requests(limit=limit)

    def get_request_by_id(self, req_id: str) -> Optional[dict]:
        return self.db.get_request_by_id(req_id)

    def get_budget_settings(self) -> BudgetSettings:
        return self.db.get_budget_settings()

    def update_budget_settings(self, settings: BudgetSettings) -> BudgetSettings:
        return self.db.update_budget_settings(settings)

    def get_cache_stats(self) -> Dict[str, Any]:
        return self.cache.get_stats()

    def clear_cache(self):
        self.cache.clear()
