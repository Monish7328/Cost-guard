"""
CostGuard - Cloud Infrastructure Cost Impact Predictor & Budget Guardrail
"""
__version__ = "1.0.0"
