"""
CostGuard SQLite Storage & Audit Trail
Manages persistence for budget settings, infrastructure requests, and historical audit logs.
"""
import sqlite3
import json
import os
import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from costguard.models import BudgetSettings, GuardrailAnalysis, GuardrailStatus

DEFAULT_DB_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "costguard.db"
)


class CostGuardDatabase:
    """Manages SQLite storage for CostGuard settings, requests, and audit logs."""

    def __init__(self, db_path: str = DEFAULT_DB_PATH):
        self.db_path = db_path
        self._init_tables()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_tables(self):
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        with self._get_connection() as conn:
            cursor = conn.cursor()

            # Budget Settings Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS budget_settings (
                    id INTEGER PRIMARY KEY,
                    company_name TEXT NOT NULL,
                    monthly_budget_limit REAL NOT NULL,
                    current_spend REAL NOT NULL,
                    max_allowed_increase REAL NOT NULL,
                    currency TEXT NOT NULL DEFAULT 'USD',
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            # Seed default settings if empty
            cursor.execute("SELECT count(*) as count FROM budget_settings")
            if cursor.fetchone()["count"] == 0:
                cursor.execute("""
                    INSERT INTO budget_settings (
                        id, company_name, monthly_budget_limit, current_spend, max_allowed_increase, currency
                    ) VALUES (1, 'Contoso Cloud Enterprise', 10000.0, 3200.0, 1000.0, 'USD')
                """)

            # Infrastructure Requests / Audit History Table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS infrastructure_requests (
                    id TEXT PRIMARY KEY,
                    user_name TEXT NOT NULL,
                    status TEXT NOT NULL,
                    prior_monthly_cost REAL NOT NULL,
                    proposed_monthly_cost REAL NOT NULL,
                    monthly_cost_delta REAL NOT NULL,
                    budget_limit REAL NOT NULL,
                    decision_reason TEXT NOT NULL,
                    items_json TEXT NOT NULL,
                    resources_json TEXT,
                    tf_plan_json TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)

            conn.commit()

    def get_budget_settings(self) -> BudgetSettings:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM budget_settings WHERE id = 1")
            row = cursor.fetchone()
            if row:
                return BudgetSettings(
                    company_name=row["company_name"],
                    monthly_budget_limit=row["monthly_budget_limit"],
                    current_spend=row["current_spend"],
                    max_allowed_increase=row["max_allowed_increase"],
                    currency=row["currency"],
                    updated_at=datetime.fromisoformat(row["updated_at"]) if row["updated_at"] else None
                )
            return BudgetSettings()

    def update_budget_settings(self, settings: BudgetSettings) -> BudgetSettings:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            now = datetime.utcnow().isoformat()
            cursor.execute("""
                UPDATE budget_settings SET
                    company_name = ?,
                    monthly_budget_limit = ?,
                    current_spend = ?,
                    max_allowed_increase = ?,
                    currency = ?,
                    updated_at = ?
                WHERE id = 1
            """, (
                settings.company_name,
                settings.monthly_budget_limit,
                settings.current_spend,
                settings.max_allowed_increase,
                settings.currency,
                now
            ))
            conn.commit()
        return self.get_budget_settings()

    def save_request(
        self,
        analysis: GuardrailAnalysis,
        user_name: str = "DevOps Engineer",
        raw_resources: Optional[List[Dict[str, Any]]] = None,
        tf_plan: Optional[Dict[str, Any]] = None
    ) -> str:
        req_id = analysis.request_id or f"REQ-{datetime.utcnow().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}"
        items_serialized = json.dumps([item.dict() for item in analysis.items])
        resources_serialized = json.dumps(raw_resources or [])
        tf_plan_serialized = json.dumps(tf_plan or {})

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO infrastructure_requests (
                    id, user_name, status, prior_monthly_cost, proposed_monthly_cost,
                    monthly_cost_delta, budget_limit, decision_reason,
                    items_json, resources_json, tf_plan_json, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                req_id,
                user_name,
                analysis.status.value,
                analysis.prior_monthly_cost,
                analysis.proposed_monthly_cost,
                analysis.monthly_cost_delta,
                analysis.budget_limit,
                analysis.reason,
                items_serialized,
                resources_serialized,
                tf_plan_serialized,
                analysis.created_at.isoformat()
            ))
            conn.commit()
        return req_id

    def list_requests(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, user_name, status, prior_monthly_cost, proposed_monthly_cost,
                       monthly_cost_delta, budget_limit, decision_reason, created_at,
                       items_json, resources_json
                FROM infrastructure_requests
                ORDER BY created_at DESC
                LIMIT ?
            """, (limit,))
            rows = cursor.fetchall()

            results = []
            for row in rows:
                results.append({
                    "id": row["id"],
                    "user_name": row["user_name"],
                    "status": row["status"],
                    "prior_monthly_cost": row["prior_monthly_cost"],
                    "proposed_monthly_cost": row["proposed_monthly_cost"],
                    "monthly_cost_delta": row["monthly_cost_delta"],
                    "budget_limit": row["budget_limit"],
                    "decision_reason": row["decision_reason"],
                    "created_at": row["created_at"],
                    "items": json.loads(row["items_json"]) if row["items_json"] else [],
                    "resources": json.loads(row["resources_json"]) if row["resources_json"] else []
                })
            return results

    def get_request_by_id(self, req_id: str) -> Optional[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM infrastructure_requests WHERE id = ?", (req_id,))
            row = cursor.fetchone()
            if not row:
                return None
            return {
                "id": row["id"],
                "user_name": row["user_name"],
                "status": row["status"],
                "prior_monthly_cost": row["prior_monthly_cost"],
                "proposed_monthly_cost": row["proposed_monthly_cost"],
                "monthly_cost_delta": row["monthly_cost_delta"],
                "budget_limit": row["budget_limit"],
                "decision_reason": row["decision_reason"],
                "created_at": row["created_at"],
                "items": json.loads(row["items_json"]) if row["items_json"] else [],
                "resources": json.loads(row["resources_json"]) if row["resources_json"] else [],
                "tf_plan_json": json.loads(row["tf_plan_json"]) if row["tf_plan_json"] else {}
            }

    def get_dashboard_summary(self) -> Dict[str, Any]:
        settings = self.get_budget_settings()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT count(*) as total, sum(case when status='APPROVED' then 1 else 0 end) as approved FROM infrastructure_requests")
            row = cursor.fetchone()
            total_requests = row["total"] or 0
            approved_requests = row["approved"] or 0
            approval_rate = round((approved_requests / total_requests * 100), 1) if total_requests > 0 else 100.0

            cursor.execute("SELECT sum(monthly_cost_delta) as approved_delta FROM infrastructure_requests WHERE status = 'APPROVED'")
            approved_delta = cursor.fetchone()["approved_delta"] or 0.0

        projected_spend = round(settings.current_spend + approved_delta, 2)
        remaining_budget = round(max(0.0, settings.monthly_budget_limit - projected_spend), 2)
        budget_utilization = round((projected_spend / settings.monthly_budget_limit * 100), 1) if settings.monthly_budget_limit > 0 else 0.0

        return {
            "company_name": settings.company_name,
            "monthly_budget": settings.monthly_budget_limit,
            "current_spend": settings.current_spend,
            "projected_spend": projected_spend,
            "remaining_budget": remaining_budget,
            "budget_utilization_pct": budget_utilization,
            "max_allowed_increase": settings.max_allowed_increase,
            "total_requests": total_requests,
            "approved_requests": approved_requests,
            "approval_rate": approval_rate
        }
