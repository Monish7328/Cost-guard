"""
Cache package initialization
"""
