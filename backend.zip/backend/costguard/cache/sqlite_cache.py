"""
SQLite Write-Through Cache for Azure Pricing
Ensures repeated queries do not hit Azure Retail Prices API unnecessarily.
Never returns fake prices.
"""
import sqlite3
import json
import os
import logging
from typing import Optional, Callable, Dict, Any
from datetime import datetime
from costguard.models import PriceQuote, PriceSource

logger = logging.getLogger("costguard.cache")

DEFAULT_DB_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "costguard.db"
)


class SQLitePriceCache:
    """Embedded SQLite write-through cache for Azure prices."""

    def __init__(self, db_path: str = DEFAULT_DB_PATH):
        self.db_path = db_path
        self._init_db()
        self.hits = 0
        self.misses = 0

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        """Create price_cache table if not already existing."""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS price_cache (
                    cache_key TEXT PRIMARY KEY,
                    service_name TEXT NOT NULL,
                    arm_sku_name TEXT NOT NULL,
                    arm_region_name TEXT NOT NULL,
                    meter_name TEXT NOT NULL,
                    product_name TEXT NOT NULL,
                    unit_price REAL NOT NULL,
                    unit_of_measure TEXT NOT NULL,
                    currency TEXT NOT NULL,
                    monthly_unit_rate REAL NOT NULL,
                    raw_metadata TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()

    @staticmethod
    def build_key(service_name: str, arm_sku_name: str, arm_region_name: str) -> str:
        """Canonical key for cache lookup."""
        return f"{service_name.strip().lower()}:{arm_sku_name.strip().lower()}:{arm_region_name.strip().lower()}"

    def get(self, service_name: str, arm_sku_name: str, arm_region_name: str) -> Optional[PriceQuote]:
        """Look up price in SQLite cache."""
        key = self.build_key(service_name, arm_sku_name, arm_region_name)
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM price_cache WHERE cache_key = ?", (key,))
            row = cursor.fetchone()
            if row:
                self.hits += 1
                return PriceQuote(
                    service_name=row["service_name"],
                    arm_sku_name=row["arm_sku_name"],
                    arm_region_name=row["arm_region_name"],
                    meter_name=row["meter_name"],
                    product_name=row["product_name"],
                    unit_price=row["unit_price"],
                    unit_of_measure=row["unit_of_measure"],
                    currency=row["currency"],
                    monthly_unit_rate=row["monthly_unit_rate"],
                    source=PriceSource.CACHE
                )
        self.misses += 1
        return None

    def put(self, quote: PriceQuote, raw_metadata: Optional[Dict[str, Any]] = None):
        """Write price quote to SQLite cache (write-through)."""
        key = self.build_key(quote.service_name, quote.arm_sku_name, quote.arm_region_name)
        with self._get_connection() as conn:
            cursor = conn.cursor()
            now = datetime.utcnow().isoformat()
            cursor.execute("""
                INSERT INTO price_cache (
                    cache_key, service_name, arm_sku_name, arm_region_name,
                    meter_name, product_name, unit_price, unit_of_measure,
                    currency, monthly_unit_rate, raw_metadata, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(cache_key) DO UPDATE SET
                    unit_price=excluded.unit_price,
                    monthly_unit_rate=excluded.monthly_unit_rate,
                    meter_name=excluded.meter_name,
                    product_name=excluded.product_name,
                    unit_of_measure=excluded.unit_of_measure,
                    raw_metadata=excluded.raw_metadata,
                    updated_at=excluded.updated_at
            """, (
                key, quote.service_name, quote.arm_sku_name, quote.arm_region_name,
                quote.meter_name, quote.product_name, quote.unit_price, quote.unit_of_measure,
                quote.currency, quote.monthly_unit_rate,
                json.dumps(raw_metadata or {}), now
            ))
            conn.commit()

    def get_or_fetch(
        self,
        service_name: str,
        arm_sku_name: str,
        arm_region_name: str,
        fetch_fn: Callable[[], PriceQuote]
    ) -> PriceQuote:
        """
        Write-through caching pattern:
        1. Check SQLite cache.
        2. If hit, return cached PriceQuote.
        3. If miss, invoke fetch_fn() to query Azure Retail Prices API.
        4. Save to SQLite cache and return PriceQuote.
        """
        cached = self.get(service_name, arm_sku_name, arm_region_name)
        if cached:
            logger.info(f"Cache HIT for {service_name} | {arm_sku_name} | {arm_region_name}")
            return cached

        logger.info(f"Cache MISS for {service_name} | {arm_sku_name} | {arm_region_name}. Fetching from Azure API...")
        fresh_quote = fetch_fn()
        self.put(fresh_quote)
        return fresh_quote

    def get_stats(self) -> Dict[str, Any]:
        """Return cache health statistics."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT count(*) as total FROM price_cache")
            total = cursor.fetchone()["total"]

            cursor.execute("SELECT service_name, count(*) as count FROM price_cache GROUP BY service_name")
            by_service = {row["service_name"]: row["count"] for row in cursor.fetchall()}

        return {
            "total_cached_items": total,
            "hits": self.hits,
            "misses": self.misses,
            "by_service": by_service,
            "db_path": self.db_path
        }

    def clear(self):
        """Flush the price cache."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM price_cache")
            conn.commit()
