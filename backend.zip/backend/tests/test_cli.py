"""
Tests for CostGuard CLI commands and exit codes
"""
import subprocess
import sys
import os
import json

EXAMPLES_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "examples"
)
BACKEND_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
)


def run_cli(args, input_data=None):
    cmd = [sys.executable, "-m", "costguard.cli"] + args
    env = os.environ.copy()
    env["PYTHONPATH"] = BACKEND_DIR
    res = subprocess.run(
        cmd,
        cwd=BACKEND_DIR,
        input=input_data,
        capture_output=True,
        text=True,
        env=env
    )
    return res


def test_cli_approved_plan():
    plan_path = os.path.join(EXAMPLES_DIR, "tfplan_approved.json")
    # With a high threshold (e.g. 1000), plan should be approved (exit 0)
    res = run_cli(["--plan", plan_path, "--max-increase", "1000", "--no-audit"])
    assert res.returncode == 0
    assert "APPROVED" in res.stdout


def test_cli_blocked_plan():
    plan_path = os.path.join(EXAMPLES_DIR, "tfplan_blocked.json")
    # With threshold 500, heavy plan should be blocked (exit 1)
    res = run_cli(["--plan", plan_path, "--max-increase", "500", "--no-audit"])
    assert res.returncode == 1
    assert "BLOCKED" in res.stdout


def test_cli_piped_input():
    plan_path = os.path.join(EXAMPLES_DIR, "tfplan_approved.json")
    with open(plan_path, "r") as f:
        content = f.read()

    res = run_cli(["--max-increase", "1000", "--no-audit", "--json"], input_data=content)
    assert res.returncode == 0
    parsed = json.loads(res.stdout)
    assert parsed["status"] == "APPROVED"


def test_cli_invalid_input():
    res = run_cli(["--plan", "non_existent_plan.json"])
    assert res.returncode == 2
