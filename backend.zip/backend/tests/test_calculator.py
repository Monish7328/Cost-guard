"""
Tests for Cost Calculator and Guardrail
"""
import pytest
from unittest.mock import MagicMock
from costguard.calculator import MonthlyCostCalculator
from costguard.guardrail import BudgetGuardrailEngine
from costguard.models import (
    BillableResource,
    ActionType,
    ResourceCategory,
    PriceQuote,
    PriceSource,
    GuardrailStatus
)


def test_monthly_calculator_create_action():
    mock_pricing = MagicMock()
    mock_cache = MagicMock()

    # Mock cache hit for VM
    mock_cache.get_or_fetch.return_value = PriceQuote(
        service_name="Virtual Machines",
        arm_sku_name="Standard_D2s_v5",
        arm_region_name="eastus",
        meter_name="D2s v5",
        product_name="Virtual Machines Dsv5 Series",
        unit_price=0.10,
        unit_of_measure="1 Hour",
        monthly_unit_rate=73.0,  # 0.10 * 730
        source=PriceSource.CACHE
    )

    calculator = MonthlyCostCalculator(pricing_client=mock_pricing, cache=mock_cache)
    resource = BillableResource(
        address="azurerm_linux_virtual_machine.vm1",
        resource_type="azurerm_linux_virtual_machine",
        action=ActionType.CREATE,
        category=ResourceCategory.COMPUTE,
        region_display="East US",
        arm_region_name="eastus",
        sku="Standard_D2s_v5",
        arm_sku_name="Standard_D2s_v5",
        quantity=2
    )

    item = calculator.calculate_resource_cost(resource)
    assert item.prior_monthly_cost == 0.0
    assert item.proposed_monthly_cost == 146.0  # 73.0 * 2
    assert item.monthly_cost_delta == 146.0


def test_guardrail_evaluation():
    engine = BudgetGuardrailEngine(default_max_increase=500.0)

    # Within budget
    analysis_approved = engine.evaluate(
        items=[],
        prior_monthly_cost=1000.0,
        proposed_monthly_cost=1350.0,
        cost_delta=350.0,
        max_allowed_increase=500.0
    )
    assert analysis_approved.status == GuardrailStatus.APPROVED
    assert "within" in analysis_approved.reason

    # Exceeds budget
    analysis_blocked = engine.evaluate(
        items=[],
        prior_monthly_cost=1000.0,
        proposed_monthly_cost=1750.0,
        cost_delta=750.0,
        max_allowed_increase=500.0
    )
    assert analysis_blocked.status == GuardrailStatus.BLOCKED
    assert "exceeds" in analysis_blocked.reason
    assert "250.00" in analysis_blocked.reason  # Overrun amount
