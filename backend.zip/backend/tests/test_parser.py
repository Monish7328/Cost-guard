"""
Tests for Terraform Plan Parser
"""
import pytest
from costguard.parser import TerraformPlanParser, TerraformParserError
from costguard.extractors import default_registry
from costguard.models import ResourceSelectionItem, ResourceCategory, ActionType


def test_parse_valid_plan_data():
    parser = TerraformPlanParser(registry=default_registry)
    plan_dict = {
        "format_version": "1.2",
        "resource_changes": [
            {
                "address": "azurerm_linux_virtual_machine.test_vm",
                "mode": "managed",
                "type": "azurerm_linux_virtual_machine",
                "change": {
                    "actions": ["create"],
                    "before": None,
                    "after": {
                        "location": "eastus",
                        "size": "Standard_D2s_v5"
                    }
                }
            }
        ]
    }
    resources = parser.parse_plan_data(plan_dict)
    assert len(resources) == 1
    assert resources[0].sku == "Standard_D2s_v5"
    assert resources[0].arm_region_name == "eastus"
    assert resources[0].action == ActionType.CREATE


def test_parse_invalid_plan():
    parser = TerraformPlanParser(registry=default_registry)
    with pytest.raises(TerraformParserError):
        parser.parse_plan_data({"invalid_key": []})


def test_build_synthetic_plan():
    parser = TerraformPlanParser(registry=default_registry)
    items = [
        ResourceSelectionItem(
            category=ResourceCategory.COMPUTE,
            resource_type="Virtual Machine",
            region="East US",
            sku="Standard_D2s_v5",
            quantity=2
        ),
        ResourceSelectionItem(
            category=ResourceCategory.STORAGE,
            resource_type="Managed Disk",
            region="East US",
            sku="Premium SSD",
            size_gb=128,
            quantity=1
        )
    ]
    synthetic = parser.build_synthetic_plan(items)
    assert "resource_changes" in synthetic
    assert len(synthetic["resource_changes"]) == 3  # 2 VMs + 1 Disk
