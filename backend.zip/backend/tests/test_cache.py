"""
Tests for SQLite Write-Through Cache
"""
import os
import tempfile
from costguard.cache.sqlite_cache import SQLitePriceCache
from costguard.models import PriceQuote, PriceSource


def test_sqlite_cache_write_and_read():
    tmp_dir = tempfile.mkdtemp()
    tmp_db = os.path.join(tmp_dir, "test_cache.db")

    try:
        cache = SQLitePriceCache(db_path=tmp_db)
        # Verify initial miss
        miss = cache.get("Virtual Machines", "Standard_D2s_v5", "eastus")
        assert miss is None

        # Put price quote
        quote = PriceQuote(
            service_name="Virtual Machines",
            arm_sku_name="Standard_D2s_v5",
            arm_region_name="eastus",
            meter_name="D2s v5",
            product_name="Virtual Machines Dsv5 Series",
            unit_price=0.096,
            unit_of_measure="1 Hour",
            monthly_unit_rate=70.08,
            source=PriceSource.AZURE_API
        )
        cache.put(quote)

        # Verify hit
        hit = cache.get("Virtual Machines", "Standard_D2s_v5", "eastus")
        assert hit is not None
        assert hit.unit_price == 0.096
        assert hit.monthly_unit_rate == 70.08
        assert hit.source == PriceSource.CACHE

        # Verify stats
        stats = cache.get_stats()
        assert stats["total_cached_items"] == 1
    finally:
        try:
            if os.path.exists(tmp_db):
                os.remove(tmp_db)
            if os.path.exists(tmp_dir):
                os.rmdir(tmp_dir)
        except Exception:
            pass
