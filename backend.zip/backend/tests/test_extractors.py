"""
Tests for Resource Extractors and Registry
"""
from costguard.extractors.vm import VirtualMachineExtractor
from costguard.extractors.disk import ManagedDiskExtractor
from costguard.extractors.gateway import GatewayExtractor
from costguard.extractors.registry import ExtractorRegistry
from costguard.models import ActionType, ResourceCategory


def test_vm_extractor():
    ext = VirtualMachineExtractor()
    assert ext.can_handle("azurerm_linux_virtual_machine")
    assert ext.can_handle("azurerm_windows_virtual_machine")
    assert not ext.can_handle("azurerm_storage_account")

    change = {
        "address": "azurerm_linux_virtual_machine.my_vm",
        "type": "azurerm_linux_virtual_machine",
        "change": {
            "actions": ["create"],
            "before": None,
            "after": {
                "location": "eastus",
                "size": "Standard_D2s_v5"
            }
        }
    }
    res = ext.extract(change)
    assert res is not None
    assert res.category == ResourceCategory.COMPUTE
    assert res.sku == "Standard_D2s_v5"
    assert res.action == ActionType.CREATE


def test_managed_disk_extractor():
    ext = ManagedDiskExtractor()
    assert ext.can_handle("azurerm_managed_disk")

    change = {
        "address": "azurerm_managed_disk.data",
        "type": "azurerm_managed_disk",
        "change": {
            "actions": ["create"],
            "before": None,
            "after": {
                "location": "centralindia",
                "storage_account_type": "Premium_LRS",
                "disk_size_gb": 128
            }
        }
    }
    res = ext.extract(change)
    assert res is not None
    assert res.category == ResourceCategory.STORAGE
    assert res.arm_region_name == "centralindia"
    assert res.raw_attributes["disk_size_gb"] == 128


def test_gateway_extractor():
    ext = GatewayExtractor()
    assert ext.can_handle("azurerm_virtual_network_gateway")

    change = {
        "address": "azurerm_virtual_network_gateway.gw",
        "type": "azurerm_virtual_network_gateway",
        "change": {
            "actions": ["create"],
            "before": None,
            "after": {
                "location": "eastus",
                "sku": "VpnGw1",
                "type": "Vpn"
            }
        }
    }
    res = ext.extract(change)
    assert res is not None
    assert res.category == ResourceCategory.NETWORKING
    assert res.sku == "VpnGw1"
